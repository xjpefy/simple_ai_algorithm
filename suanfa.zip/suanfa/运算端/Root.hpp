#include <cstdint>
#include <cstddef>
#include <functional>
#include <string>
#include <stdint.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <deque>
#include <unordered_set>
#include <unordered_map>
#include <chrono>
#include <random>
#include <mutex>
#include <atomic>

using namespace std;

typedef unsigned int ID;
typedef unsigned int INDEX;


// 硬盘存储结构


atomic<long long> Code_Time = 0;

// 运算端状态控制量
char IF_SELF_TURN_OFF = 1; // 整体程序开关
char IF_SELF_COMMUNIATE = 0;
char IF_SELF_CONNECT = 0;
char IF_SELF_WORKING = 0; // 模型运行开关

// 执行端状态控制量
char IF_NEED_COMMUNIATE = 1;
char IF_NEED_WORKING = 1;
char IF_NEED_CAPTURE = 0;
char IF_NEED_ACTION = 0;

atomic<ID> NEWIST_USEFUL_ID = 1;  // 最新可用节点id
atomic<long long> CURRENT_MODEL_TIME = 100; // 模型时间，不依赖系统时间，是模型迄今为止运行过的时间，每1ms前进一
atomic<unsigned int> ALL_NUM_OF_CH = 0;     // 存在的字符数量
atomic<unsigned int> LAST_PACK_NUMBER = 0;  // 快速读取文件的包数

atomic<int> FREE_ID_NUM = 0;
vector<ID> FREE_ID_LIST; // 曽被删除的节点id
atomic<int> Free_Id_Ocuppy(0);

atomic<int> CURRENT_SYSTEM_MEMORY;

// 包使用频度计算 使用频度与重要性
char time_curr = 0;
atomic<long long> use_time[4] = {0, 0, 0, 0};
atomic<int> time_node_occupy[4] = {0, 0, 0, 0};
atomic<int> node_total_occupy = 0;


// 模型状态记录文件
struct state_record_file
{
    ID newist_useful_id = 1; // 最新可用编号
    unsigned int all_num_of_ch = 0;    // 存在的字符数量
    unsigned int last_pack_num = 0;    // 预读取文件的包数

    char time_curr = 0;
    int time_node_occupy[4] = {0, 0, 0, 0};
    long long use_time[4] = {0, 0, 0, 0};
    long long node_total_occupy = 0;

    long long current_model_time = 100; // 已用模型时间
    long long size_of_pre_load_file = 0;
};


// 初始化状态记录文件
void load_model_record()
{
    // 打开文件
    FILE *fp = fopen("Record_Model_State.rec", "r");

    state_record_file rf;
    state_record_file *ptr = &rf;
    // 失败，创建文件
    if (fp)
    {
        // 成功，读入文件
        fread(ptr, sizeof(state_record_file), 1, fp);

        fseek(fp, sizeof(state_record_file), 1);
        fread(&FREE_ID_NUM, sizeof(int), 1, fp);

        FREE_ID_LIST.resize(FREE_ID_NUM);
        fseek(fp, sizeof(int), 1);
        fread(FREE_ID_LIST.data(), sizeof(int) * FREE_ID_NUM, 1, fp);

        fclose(fp); // 关闭
    }
    // 赋予文件属性
    NEWIST_USEFUL_ID = rf.newist_useful_id;
    CURRENT_MODEL_TIME = rf.current_model_time;
    ALL_NUM_OF_CH = rf.all_num_of_ch;
    LAST_PACK_NUMBER = rf.last_pack_num;

    time_curr = rf.time_curr;
    time_node_occupy[0] = rf.time_node_occupy[0];
    time_node_occupy[1] = rf.time_node_occupy[1];
    time_node_occupy[2] = rf.time_node_occupy[2];
    time_node_occupy[3] = rf.time_node_occupy[3];
    use_time[0] = rf.use_time[0];
    use_time[1] = rf.use_time[1];
    use_time[2] = rf.use_time[2];
    use_time[3] = rf.use_time[3];
    node_total_occupy = rf.node_total_occupy;
}

// 运行状态记录保存
void save_record_model()
{
    // 打开文件
    FILE *fp = fopen("Record_Model_State.rec", "w");
    state_record_file rf;
    state_record_file *ptr = &rf;

    // 赋予文件属性
    rf.newist_useful_id = NEWIST_USEFUL_ID;
    rf.current_model_time = CURRENT_MODEL_TIME;
    rf.all_num_of_ch = ALL_NUM_OF_CH;
    rf.last_pack_num = LAST_PACK_NUMBER;

    rf.time_curr = time_curr;
    rf.time_node_occupy[0] = time_node_occupy[0];
    rf.time_node_occupy[1] = time_node_occupy[1];
    rf.time_node_occupy[2] = time_node_occupy[2];
    rf.time_node_occupy[3] = time_node_occupy[3];
    rf.use_time[0] = use_time[0];
    rf.use_time[1] = use_time[1];
    rf.use_time[2] = use_time[2];
    rf.use_time[3] = use_time[3];
    rf.node_total_occupy = node_total_occupy;

    fwrite(ptr, sizeof(state_record_file), 1, fp);

    fseek(fp, sizeof(state_record_file), 1);
    fwrite(&FREE_ID_NUM, sizeof(int), 1, fp);

    fseek(fp, sizeof(int), 1);
    fwrite(FREE_ID_LIST.data(), sizeof(int) * FREE_ID_NUM, 1, fp);

    // 关闭
    fclose(fp);
}

// 单个存储包内部结构
struct Pack_Inside
{
    int attribute_item[256];
};
// 256*4字节

vector<Pack_Inside> Neuro_Pack_Storage;         // 神经元包的存储，占很大内存，10~20g
vector< atomic<char> > Neuro_Pack_Read_Occupy;  // 对包占用数据记录，控制同时读，不可写
vector< atomic<char> > Neuro_Pack_Write_Occupy; // 写时不可再 读写
atomic<int> Push_Neuro_Pack_Occupy(0);

unordered_map<ID, INDEX> Pack_Vector_Index_Find;   // 存储神经元包下标
vector<INDEX> Free_Pack_Index_List;  // 空包回收
vector<INDEX> Free_2_Pack_Index_List;
vector<INDEX> Free_4_Pack_Index_List;
vector<INDEX> Free_8_Pack_Index_List;
atomic<int> Push_Neuro_Pack_Record_Occupy(0);

long long Pack_Limit = 10 * 10000; // 1500 * 10000包量略小于16g，1200 * 10000略小于13g
atomic<long long> Free_Pack_Num(Pack_Limit - 1);
atomic<long long> Current_Pack_Num(1);



struct Pack_Record
{
    char is_use = 1;
    char pack_state = 1; // 包状态，可使用空间0，待存储读入1，空闲中2，使用中3，修改中4，连带包5，待存储写入6
    char pack_size = 0;
    char time_curr = 0;

    ID pack_id = 0; // 自身编号

    int use_time[8] = {0, 0, 0, 0, 0, 0, 0, 0}; // 时间清理统计
    int history_use_num[4] = {0, 0, 0, 0};      // 被占用的总数
};
// 14*4字节

vector<Pack_Record> Neuro_Pack_Record_Storage;  // 神经元包的存储记录
vector< atomic<char> > Neuro_Pack_Record_Occupy;// 读写占用


// 上次运行结束数据读取
void load_pre_load_file()
{
    // 存储初始化
    Neuro_Pack_Storage.reserve(Pack_Limit);
    Neuro_Pack_Storage.resize(1 + LAST_PACK_NUMBER);
    
    Neuro_Pack_Record_Storage.reserve(Pack_Limit);
    Neuro_Pack_Record_Storage.resize(1 + LAST_PACK_NUMBER);
    
    // 原子类型的初始化
    // Neuro_Pack_Read_Occupy.resize(Pack_Limit);
    // Neuro_Pack_Write_Occupy.resize(Pack_Limit);
    // Pack_Vector_Index_Find.reserve(Pack_Limit);

    if (!LAST_PACK_NUMBER)
        return; // 无记录

    FILE* fp_I = fopen("Record_Pre_Load_File_I.rec", "r");
    FILE* fp_II = fopen("Record_Pre_Load_File_II.rec", "r");

    if (fp_I && fp_II)
    {
        int size_neuro_inside = sizeof(Pack_Inside);
        int size_neuro_record = sizeof(Pack_Record);

        Pack_Inside single_data;
        Pack_Inside* single_data_ptr = &single_data;

        Pack_Record single_record;
        Pack_Record* single_record_ptr = &single_record;

        int i = 1;

        while (i <= LAST_PACK_NUMBER)
        {
            fread(single_data_ptr, size_neuro_inside, 1, fp_I);
            fread(single_record_ptr, size_neuro_record, 1, fp_II);

            Neuro_Pack_Storage[i] = single_data;
            Neuro_Pack_Record_Storage[i] = single_record;

            if (single_record.pack_state)
                Pack_Vector_Index_Find[single_record.pack_id] = i;
            else
                Free_Pack_Index_List.push_back(i);

            fseek(fp_I, size_neuro_inside, 1);
            fseek(fp_II, size_neuro_record, 1);

            i++;
        }

        fclose(fp_I);
        fclose(fp_II);
    }
}

// 下次运行初始数据保存
void save_pre_load_file()
{
    FILE *fp = fopen("Record_Pre_Load_File.rec", "w");
    LAST_PACK_NUMBER = Neuro_Pack_Storage.size() - 1;
    fwrite(Neuro_Pack_Storage.data() + 1, LAST_PACK_NUMBER * sizeof(Pack_Inside), 1, fp);
    fclose(fp);
}

// 包位置查找
INDEX pack_index_find(ID target)
{
    auto position = Pack_Vector_Index_Find.find(target);

    if (position != Pack_Vector_Index_Find.end())
        return (position->second); // 在存储中的下标
    else
        return 0; // 包不存在
}

// 包位置提供
INDEX pack_position_insert(ID target, char pack_num) // 返回下标
{
    INDEX first_idx;
    INDEX idx;

    if(Free_Pack_Num.load() < 16)
        return 0;

    Current_Pack_Num.fetch_add(pack_num);

    //四种大小的包的需求
    if(pack_num == 1)
    {
        if (!Free_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while(Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;

            idx = Free_Pack_Index_List.back();
            Free_Pack_Index_List.pop_back();

            expected = 1;
            while(Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
            
            first_idx = idx;

            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
            Neuro_Pack_Record_Storage[idx].pack_state = 1;

        } else { // 新建
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;

            Pack_Inside new_object; 

            int expected = 0;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;

            idx = Neuro_Pack_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);
            Neuro_Pack_Storage.push_back(new_object);

            expected = 1;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }
    } else if(pack_num == 2) {

        char curr_check = 0;
        INDEX cover_check[8];
        char suitable_success = 1;

        while (!Free_2_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while( !Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;

            idx = Free_2_Pack_Index_List.back();
            Free_2_Pack_Index_List.pop_back();

            expected = 1;
            while( !Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;

            //三重检验
            char expected_char = 0;

            //存储连续性检验
            while(curr_check < pack_num && suitable_success != 0)
            {
                //提前筛出
                if(Neuro_Pack_Record_Storage[idx].pack_state != 0)
                {
                    suitable_success = 0;
                    break;
                }

                //非写
                while(!Neuro_Pack_Write_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;
                  
                //非读
                while(!Neuro_Pack_Read_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;

                //非占用
                if(Neuro_Pack_Record_Storage[idx].pack_state == 0)
                {
                    cover_check[curr_check] = idx;
                    curr_check++;

                    if(curr_check == pack_num - 1)
                    {
                        suitable_success = 2;
                        curr_check = 0;
                        first_idx = cover_check[0];
                        
                        //全体包填写
                        while(curr_check < pack_num)
                        {
                            idx = cover_check[curr_check];
                            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
                            Neuro_Pack_Record_Storage[idx].pack_state = 1;

                            //解除占用
                            Neuro_Pack_Write_Occupy[idx].fetch_sub(1);
                            Neuro_Pack_Read_Occupy[idx].fetch_sub(1);
                        }
                    }//成功找到连续位置

                } else {
                    suitable_success = 0;
                    break;
                }
            }
            
        }// 覆盖结束 或 失败
        
        if (Free_2_Pack_Index_List.empty() && suitable_success != 2)
        {
            // 新建
            int expected = 0;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;
            
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;
            idx = Neuro_Pack_Record_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);

            first_idx = idx;

            Pack_Inside new_object; 
            Neuro_Pack_Storage.push_back(new_object);
            pack_num--;

            while(pack_num)
            {
                Pack_Record new_record;
                new_record.pack_state = 5;
                idx = Neuro_Pack_Record_Storage.size();
                Neuro_Pack_Record_Storage.push_back(new_record);

                Pack_Inside new_object; 
                Neuro_Pack_Storage.push_back(new_object);
                pack_num--;
            }

            expected = 1;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }

    } else if(pack_num == 4) {

        char curr_check = 0;
        int cover_check[8];
        char suitable_success = 1;

        while (!Free_4_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while( !Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                 expected = 0;
            
            idx = Free_4_Pack_Index_List.back();
            Free_4_Pack_Index_List.pop_back();

            expected = 1;
            while( !Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                 expected = 1;
            //三重检验
            char expected_char = 0;

            //存储连续性检验
            while(curr_check < pack_num && suitable_success != 0)
            {
                //提前筛出
                if(Neuro_Pack_Record_Storage[idx].pack_state != 0)
                {
                    suitable_success = 0;
                    break;
                }

                //非写
                while(!Neuro_Pack_Write_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;
                
                //非读
                while(!Neuro_Pack_Read_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;

                //非占用
                if(Neuro_Pack_Record_Storage[idx].pack_state == 0)
                {
                    cover_check[curr_check] = idx;
                    curr_check++;

                    if(curr_check == pack_num - 1)
                    {
                        suitable_success = 2;
                        curr_check = 0;
                        first_idx = cover_check[0];
                        
                        //全体包填写
                        while(curr_check < pack_num)
                        {
                            idx = cover_check[curr_check];
                            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
                            Neuro_Pack_Record_Storage[idx].pack_state = 1;

                            //解除占用
                            Neuro_Pack_Write_Occupy[idx].fetch_sub(1);
                            Neuro_Pack_Read_Occupy[idx].fetch_sub(1);
                        }
                    }//成功找到连续位置

                } else {
                    suitable_success = 0;
                    break;
                }
            }
            
        }// 覆盖结束 或 失败
        
        if (Free_4_Pack_Index_List.empty() && suitable_success != 2)
        {
            // 新建
            int expected = 0;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;
            
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;
            idx = Neuro_Pack_Record_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);

            first_idx = idx;

            Pack_Inside new_object; 
            Neuro_Pack_Storage.push_back(new_object);
            pack_num--;

            while(pack_num)
            {
                Pack_Record new_record;
                new_record.pack_state = 5;
                idx = Neuro_Pack_Record_Storage.size();
                Neuro_Pack_Record_Storage.push_back(new_record);

                Pack_Inside new_object; 
                Neuro_Pack_Storage.push_back(new_object);
                pack_num--;
            }

            expected = 1;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }

    } else if(pack_num == 8) {
        
        char curr_check = 0;
        int cover_check[8];
        char suitable_success = 1;

        while (!Free_8_Pack_Index_List.empty())
        { // 覆盖
            int expected = 0;
            while( !Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 0;
            idx = Free_8_Pack_Index_List.back();
            Free_8_Pack_Index_List.pop_back();

            expected = 1;
            while( !Push_Neuro_Pack_Record_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
            //三重检验
            char expected_char = 0;

            //存储连续性检验
            while(curr_check < pack_num && suitable_success != 0)
            {
                //提前筛出
                if(Neuro_Pack_Record_Storage[idx].pack_state != 0)
                {
                    suitable_success = 0;
                    break;
                }

                //非写
                while(!Neuro_Pack_Write_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;
                
                //非读
                while(!Neuro_Pack_Read_Occupy[idx].compare_exchange_strong(expected_char, 1, memory_order_seq_cst))
                    expected_char = 0;

                //非占用
                if(Neuro_Pack_Record_Storage[idx].pack_state == 0)
                {
                    cover_check[curr_check] = idx;
                    curr_check++;

                    if(curr_check == pack_num - 1)
                    {
                        suitable_success = 2;
                        curr_check = 0;
                        first_idx = cover_check[0];
                        
                        //全体包填写
                        while(curr_check < pack_num)
                        {
                            idx = cover_check[curr_check];
                            Neuro_Pack_Record_Storage[idx].pack_size = pack_num;
                            Neuro_Pack_Record_Storage[idx].pack_state = 1;

                            //解除占用
                            Neuro_Pack_Write_Occupy[idx].fetch_sub(1);
                            Neuro_Pack_Read_Occupy[idx].fetch_sub(1);
                        }
                    }//成功找到连续位置

                } else {
                    suitable_success = 0;
                    break;
                }
            }
            
        }// 覆盖结束 或 失败
        
        if (Free_8_Pack_Index_List.empty() && suitable_success != 2)
        {
            // 新建
            int expected = 0;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
                expected = 0;
            
            Pack_Record new_record;
            new_record.pack_size = pack_num;
            new_record.pack_state = 1;
            idx = Neuro_Pack_Record_Storage.size();
            Neuro_Pack_Record_Storage.push_back(new_record);

            first_idx = idx;

            Pack_Inside new_object; 
            Neuro_Pack_Storage.push_back(new_object);
            pack_num--;

            while(pack_num)
            {
                Pack_Record new_record;
                new_record.pack_state = 5;
                idx = Neuro_Pack_Record_Storage.size();
                Neuro_Pack_Record_Storage.push_back(new_record);

                Pack_Inside new_object; 
                Neuro_Pack_Storage.push_back(new_object);
                pack_num--;
            }

            expected = 1;
            while( Push_Neuro_Pack_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
                expected = 1;
        }
    }
    
    Pack_Vector_Index_Find[target] = first_idx;

    return first_idx;
} // 函数结束

// 包删除
void pack_delete(ID target)
{
    INDEX pack_idx = pack_index_find(target);

    if (pack_idx == 0)
        return;

    // 目标存在
    Pack_Vector_Index_Find.erase(target);
    Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;

    char pack_size = Neuro_Pack_Record_Storage[pack_idx].pack_size;

    if(pack_size == 1)
    {
        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_Pack_Index_List.push_back(pack_idx);

    } else if(pack_size == 2) {

        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_2_Pack_Index_List.push_back(pack_idx);

    } else if(pack_size == 4) {

        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_4_Pack_Index_List.push_back(pack_idx);

    } else if(pack_size == 8) {

        Neuro_Pack_Record_Storage[pack_idx].pack_state = 0;
        Free_8_Pack_Index_List.push_back(pack_idx);
    }
    
    //未原子化 和 多空余队列添加

} // 函数结束

//鏇炬湁浜鸿杩囧垇缁翠粬灏辨槸涓椽鐢熺晱姝荤殑姣掕穿锛屾垜杩樹互涓哄彧鏄瑧璇濓紝璋佷細鎯冲埌杩欐槸鐪熺殑

// 生成随机值 均等生成 0~255 之内的随机数
inline uint8_t rand_0_to_255()
{
    static thread_local uint32_t x = 764182953u;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return uint8_t(x);
}

// 共享随机值生成
random_device Overall_RD;
mt19937 Overall_Gen(Overall_RD());

// 记忆管理
atomic<int> current_0_1s_memory_value = 0; // 0.1秒内神经元读写的总量
char memory_time_num = 0;
float total_memory_value_10s_average = 0;

atomic<int> newly_use_memoey = 0; //新增神经元控制
int newly_memory_max_value = 5; // 不能超过总值，不能超过写值
float newly_memory_max_rate = 0.05; // 中的
float newly_memory_attract = 1;

atomic<int> restore_memory_need_value = 0; // 写入的神经元 数量in0.1s
float restore_memory_rate;

atomic<int> recall_memory_need_value = 0; // 读入的神经元 数量in0.1s
float recall_memory_rate;

// 待读取任务队列
deque<ID> Will_Read_Neuro_Queue;
mutex mutex_will_read;

// 待写入任务队列
deque<ID> Will_Write_Neuro_Queue;
mutex mutex_will_write;

void add_to_Will_Read_Neuro_Queue(unsigned int target)
{
    mutex_will_read.lock();
    Will_Read_Neuro_Queue.push_back(target);
    mutex_will_read.unlock();

    recall_memory_need_value.fetch_add(1);
}

void add_to_Will_Write_Neuro_Queue(unsigned int target)
{
    mutex_will_write.lock();
    Will_Write_Neuro_Queue.push_back(target);
    mutex_will_write.unlock();
    
    restore_memory_need_value.fetch_add(1);
}

// 一字节转string类型
string byteToHex(uint8_t byte)
{
    string out;
    static const char hex[] = "0123456789ABCDEF";
    out[0] = hex[(byte >> 4) & 0x0F]; // 高 4 位
    out[1] = hex[byte & 0x0F];        // 低 4 位
    return out;
}

// unsigned int类型的量转化成路径
string VariableToPath(unsigned int target)
{
    // 目录名生成
    string dir1 = byteToHex(static_cast<unsigned char>((target >> 24) & 0xFF));
    string dir2 = byteToHex(static_cast<unsigned char>((target >> 16) & 0xFF));
    string dir3 = byteToHex(static_cast<unsigned char>((target >> 8) & 0xFF));
    string name4 = byteToHex(static_cast<unsigned char>((target) & 0xFF));

    // 构建目录路径 （ linux版路径）
    std::string directory;
    directory = dir1 + "/" + dir2 + "/" + dir3 + "/" + name4 + ".n";

    // 返回完整路径
    return directory;
} // 函数结束

// 计算神经元消耗的存储空间
long long ALL_NEURO_RAM = 0;

// 内存消耗计算函数，未完成改，无含网络占用统计
void ram_coast()
{
    ALL_NEURO_RAM = sizeof(Pack_Inside) * Neuro_Pack_Storage.size();
}

long long one_G = 1024 * 1024 * 1024;

long long LIMIT_RAM = 24 * one_G; // 允许的上限内存

float Pack_Attract_Rate = 0;

int gap_time = 16 * 256; // 约4s

long long time_update_gap = 0xFFFFFFFFFFFFF000;

// 神经元使用记录 更新
void neuro_use_record_update(unsigned int target_id)
{
    // 更新
    INDEX idx = Pack_Vector_Index_Find[target_id];
    Pack_Record& pack_record = Neuro_Pack_Record_Storage[idx];

    long long curr_time = 0;
    long long front = pack_record.use_time[pack_record.time_curr * 2];
    front = front << 32;
    long long back = pack_record.use_time[pack_record.time_curr * 2 + 1];
    curr_time |= front;
    curr_time |= back;

    if (curr_time != (CURRENT_MODEL_TIME & time_update_gap) )
    {
        pack_record.time_curr += 1;

        if (pack_record.time_curr >= 4)
            pack_record.time_curr = 0;

        curr_time = CURRENT_MODEL_TIME & time_update_gap;

        pack_record.use_time[pack_record.time_curr * 2] = curr_time >> 32;
        pack_record.use_time[pack_record.time_curr * 2 + 1] = curr_time & 0xffffffff;
    }

    pack_record.history_use_num[pack_record.time_curr] += 1;

    time_node_occupy[time_curr] += 1;

} // 使用次数更新函数结束


// 冷包剔除
void Cool_Pack_Delete_Thread()
{
    //非重要内存数据剔除
    int Half_Pack_Limit = Pack_Limit * 0.5;

    while (IF_SELF_TURN_OFF)
    {
        // 包增加容忍度计算公式
        Pack_Attract_Rate = (Half_Pack_Limit - Current_Pack_Num.load()) / Half_Pack_Limit;

        for (int a = 0; a < 4; a++)
            node_total_occupy += time_node_occupy[a];

        float ave_occupy = node_total_occupy / (Current_Pack_Num.load() + 1);

        // 使用频度 数据占用程度，取时间使用性
        int i = 1;
        while (i < Neuro_Pack_Storage.size())
        {
            Pack_Record& pack_record = Neuro_Pack_Record_Storage[i];

            if (pack_record.pack_state == 0 || pack_record.pack_state != 2)
                continue;

            int curr_pack_total_history_use_num = 0;
            long long low_permit = use_time[time_curr] - 4 * gap_time;

            for (int b = 0; b < 4; b++)
            {
                if (*(long long *)(pack_record.use_time + 2 * b) < low_permit)
                    continue;
                
                curr_pack_total_history_use_num += pack_record.history_use_num[b];
            }

            float Curr_Pack_Attract = (curr_pack_total_history_use_num - ave_occupy) / ave_occupy;

            // 触发删除判定
            if (CURRENT_MODEL_TIME - *(long long *)(pack_record.use_time + pack_record.time_curr * 2) > 360000 // 360秒未使用
                || Curr_Pack_Attract + Pack_Attract_Rate < 0)
            {
                // 包使用记录 删除
                pack_record.pack_state = 6;

                // 删除包
                add_to_Will_Write_Neuro_Queue(pack_record.pack_id);
            } // 触发删除判定 解决
            i++;

        } // 遍历完一个包

        i = 1;
    } // 重复工作
}


// 神经元查找，返回节点首字节的指针
int* node_find(ID target)
{
    int vec_pos = pack_index_find(target);

    if (vec_pos == -1)
        return 0;

    neuro_use_record_update(target);

    int * return_ptr = Neuro_Pack_Storage[vec_pos].attribute_item;
    
    return return_ptr;
} // 函数结束


// 神经元相关属性

// 神经元头部数据
struct Neuro_Head_Attribute
{
    unsigned char neuro_kind;     // 节点性质
    unsigned char node_size = 1;  // 节点大小
    unsigned short used_item_num = 0;   // 已用节点特征数量，limit上限:256、512、1024
}; // 神经元架构，1*4字节

// 神经元节点 头部数据返回
Neuro_Head_Attribute neuro_head_read(int x) // 输入头目属性
{
    Neuro_Head_Attribute s;
    s.neuro_kind = (x >> 24) & 0xFF;
    s.node_size = (x >> 16) & 0xFF;
    s.used_item_num = x & 0xFFFF;
    return s;
} // 函数结束


// 图像神经元描述
struct Neuro_Image_Desc
{
    char neuro_is_image = 1;
    char detail_kind;    // 线段形态1，色彩线段2，复合图形3
    char limit_predict_num = 8;
    char all_predict_stability_num = 0; // 上限8/16/32

    int neuro_active_num = 0; // 使用次数
    int self_attention = 0;

    //理解需求相关

    //
    float predict_stability_8 = 0; // 预测稳定性(8次以内)
    // float predict_stability_32 = 0; // 预测稳定性(32次以内)
    float forward_predict_stability = 0; // 时
    float backward_predict_stability = 0;

    // 
    float upward_predict_ability = 0; // 空
    float downward_predict_ability = 0;
    float left_predict_ability = 0;
    float right_predict_ability = 0;

    float appear_worth = 0; // 出现价值，由注意力结合生成率 汇总而成
    //减少了多少预测/识别消耗，或者预测/识别了多少
    //重复 累余了多少 降低价值
    //支持其上的节点的价值
    //长期预测繁复

    //出现幅度衡量

    //外部好感
    float puruse = 0;

    //9int

    //理解需求 和 实现需求

    // 内部属性数

    // 独有属性
    // unsigned char red;
    // unsigned char green;
    // unsigned char blue;

    // unsigned char length;
    // unsigned char direction;


}; // 15*4字节，神经元架构

// 文本神经元描述
struct Neuro_Text_Desc
{
    char neuro_is_text = 2;
    char detail_kind;   // 字符1 文本2
    char limit_predict_num = 8;
    char predict_stability_num = 0; // 使用上限8/16/32

    int neuro_active_num = 0; // 使用次数
    int self_attention = 0;

    float predict_stability = 0; // 预测稳定性 与其他值控制 model_require_average

    float forward_predict_stability = 0;
    float backward_predict_stability = 0;
    // 6

    // 内部属性数
    // int stat_num = 0;    // 统计属性数量
    // int fusion_num = 0;  // 聚合属性数量

}; // 15*4字节，神经元架构

// 概念神经元描述
struct Neuro_Concept_Desc
{
    char neuro_is_concept = 3;
    char be_restrain_num = 0;
    char limit_predict_num = 8;
    char predict_stability_num = 0; // 上限8/16/32

    int neuro_active_num = 0; // 使用次数
    int self_attention = 0;
    // 3*4字节

    float predict_stability = 0; /* 预测稳定性，这个值是平均数，加上最近的节点值再平均，
    精度有损的估计方法，但是存储很低就可以获取最近时间内的需求 */

    // 内部属性数
};
// 15*4字节，神经元架构


//
union Neuro_Desc
{
    Neuro_Image_Desc image_desc;
    Neuro_Text_Desc text_desc;
    Neuro_Concept_Desc concept_desc;
};

//图像条目
struct Neuro_Image_Item
{
    char item_is_image = 1;
    char logic;         // 生成逻辑(0无1有) 或 需求逻辑(模拟中应该有1)
    char related_scale; // 相对尺度，正数为当前尺度偏对方大 负数为当前尺度偏对方小 1为使用尺度相同

    char direction; // 方向区间
    char direction_scale = 3;   // 方向覆盖规模 0(无方向性)、1=1、2=3、3=5 向两旁蔓延的幅度
    char distance;  // 距离区间
    char distance_scale = 3;    // 距离覆盖规模 0(无距离性)、1=1、2=3、3=5，原区间+-得到
    
    ID related_id;
};
// 3*4字节，神经元架构

struct Neuro_Colour_Item
{
    char item_is_colour;
    char red;
    char green;
    char blue;
};

// 内部自定位条目
struct Self_Cognition_Item
{
    unsigned char coding_mode = 0; // 叠层1，直接2，延续叠层3
    unsigned char self_inside_I = 0;
    unsigned char self_inside_II = 0;
    unsigned char self_inside_III = 0;
};
// 1*4字节

// 主动观测条目
struct Initiative_Observation_Item
{
    //方向，距离
    //
    ID target;
};

// 数量条目
struct Neuro_Number_Item
{
    char item_is_number = 2;
    char detail = 0; // 作概率统计1、作数量统计2、作数量达标下限3、作数量达标上限4、作数量区间5
    char logic = 0; // 不存在0 存在1
    char joint = 0; // 

    int number_I = 0; // active_stat激活、统计的次数
    int number_II = 0; // realize_detect实现、探测的次数
};
// 3*4字节，神经元架构

// 时间条目
struct Neuro_Time_Item
{
    char item_is_time = 3;
    char logic = 0;    //不存在0 存在1
    char time_range;    // 时间区域(-4~4)，0是同时，1是从此刻至一尺度时间，2是一尺度至二尺度，类推
    char time_scale;    // 时间规模，通常是0是无规模(仅模糊方向)，1是0.1秒，2是0.2秒(每次乘2倍)，3是0.4秒，类推1、2、3、4、5

    char effect_kind;   // 生成时间 生成概念

    ID related_id;// 生成对象
};
// 3*4字节，神经元架构

// 文本条目
struct Neuro_Text_Item
{
    char item_is_text = 4;
    char logic = 0; // 不存在0 存在1
    char effect_kind; // 生成文本1，生成概念2  或 统计字符1，统计字符串2

    char left_distance = 1;           // 左端作用位置，-8～8
    char right_distance = 1;          // 右端作用位置，-8～8
    unsigned char distance_scale = 4; // 距离幅度，2的指数，1，2，4，8
    
    ID target_id;
};
// 3*4字节，神经元架构

// 概念条目
struct Neuro_Concept_Item
{
    char item_is_concep = 5;
    char logic = 0; // 不存在0 存在1

    ID target_id;
};
// 2*4字节，神经元架构

// 行动条目
struct Neuro_Action_Item
{
    char item_is_action = 6;
    char logic; // 不存在0 存在1

    char action_kind;   // 鼠标1，键盘2，文本传回3，文本显示4，窗口隐藏5，窗口显示6
    char mouseData; // 滚轮为乘120
    unsigned char vk; // 键码
    
    char direction; // 方向区间
    char distance;  // 距离区间

    unsigned int dwFlags;

    ID locate_id; // 行为定位本体id 附属在待操作的图形条件的定位点
};
// 4*4字节，神经元架构

// 两者同一的信念，未经证实的推测，文本呈递的经验
// 信念条目
struct Neuro_Belief_Item
{
    char item_is_belief = 7; // 
    char detail_kind; // 等同/同一/对应1，产生2，信息3
    char logic; // 不存在0 存在1
    char effect_kind; // 图像结果1 文本结果2 概念结果3

    int u_value = 0;
    int l_value = 0; // 信念强度 信念概率 置信度
    
    ID belief_object_id; // 等同的对象
};
//4*4字节，神经元架构

// 态度条目
struct Neuro_Manner_Item
{
    char item_is_manner = 8;
    char manner_kind; // 注意力需求1 注意力转移2 识别需求3 理解需求4 选择需求5（实现需求5）
    char target_kind; // id1 场景2
    
    int manner_value = 0; // - ～ +
    float manner_rate = 0; // 比例
    ID effect_target;
};
//4*4字节

//统计指标：关注度(注意力值) 清楚度(识别上的完全与认为识别上的完全) 可能性(情境内共存的概率)
//追求指标：好感度(外部实现 的 构造需求) 求知欲(建模需求) 合理性(建模需求的一个指标)

// 概率抑制条目
struct Neuro_Casual_Restrain_Item
{
    ID Restrain_Target;
    
};


//神经元间链接
union Neuro_Link_Attribute
{
    Neuro_Image_Item image_attribute;
    Neuro_Text_Item text_attribute;
    Neuro_Time_Item time_attribute;
    Neuro_Number_Item number_attribute;
    Neuro_Concept_Item concept_attribute;
    Neuro_Action_Item action_attribute;
    Neuro_Belief_Item belief_attribute;
    Neuro_Manner_Item manner_attribute;
};


// 通用条件
union General_Condition
{
    Neuro_Image_Item image_condition;
    Neuro_Time_Item time_condition;
    Neuro_Text_Item text_condition;
    Neuro_Number_Item number_condition;
    Neuro_Concept_Item concept_condition;
    Neuro_Action_Item action_conditon;
};

// 通用结果
union General_Result
{
    Neuro_Image_Item image_result;
    Neuro_Time_Item time_result;
    Neuro_Text_Item text_result;
    Neuro_Number_Item number_result;
    Neuro_Concept_Item concept_result;
    Neuro_Belief_Item belief_result;
    Neuro_Manner_Item manner_result;
};

// 通用属性
struct General_Flow_Attribute
{
    //
    unsigned char attritube_kind; /* 前四比特：统计1，生成2，下级3，类别6，抑制5，主动6，对应7 */
    unsigned char update_kind = 0;
    unsigned char number_of_condition_and_result;
    unsigned char non;
    
    int active_stat_num;    // 激活、统计的次数
    int realize_detect_num; // 生成、实现的次数

    //
    General_Condition condition[4];
    General_Result result[4];
    //

}; //(4~23)*4字节，神经元架构

struct Attribute_Head
{
    char attribute_kind; // 必填，统计1，生成2，分解3，类别4，（抑制5，行动6，态度7，对应8）
    /*写入一些属性的标识*/
    char able_update = 0; // 可升级1 已有升级精细化2 已有升级节点化3 已有升级多样化4
    
    // 条件类型，图像1、数量2，时间3、文本4、行动5
    char condition_num = 0; // 必填

    // 结果类型，图像1、数量2、时间3、文本4、信念5、态度6
    char result_num = 0; // 必填

    char item_num; // 所占4字节的数量
};

char every_item_size[8] = {3, 3, 3, 3, 2, 4, 4, 4};


//简单的读取数据，未完成
int* return_item_kind_and_size(int* ptr, char item_order, char& item_kind, char& item_size)
{
    for(int q = 0; q < item_order; q++)
    {
        ptr += item_size;
        item_kind = *(char*)(ptr);
        item_size = every_item_size[item_kind];
    }
    
    return ptr;
}


// 记录条目解析
Attribute_Head attribute_head_get(int *ptr)
{
    char one = *(char *)ptr;
    char two = *((char *)ptr + 1);
    char three = *((char *)ptr + 2);
    char four = *((char *)ptr + 3);

    Attribute_Head return_item;

    return_item.attribute_kind = one >> 4;
    return_item.able_update = one & 0xf;
    
    return_item.condition_num = three >> 4;
    return_item.result_num = three & 0xf;

    // return_item.item_num = 3 + condition_size * (return_item.condition_num + three)
    //     + result_size * (return_item.result_kind + four);

    return return_item;
}


// 记录条目写入
void attribute_head_put(Attribute_Head item_head, vector<int>& target_list)
{
    int *ptr = target_list.data();

    char condition_kind;
    char result_kind;
    char condition_num = item_head.result_num;
    char result_num = item_head.result_num;

    char condition_size;
    char result_size;

    if (condition_kind == 2 || condition_kind == 5)
        condition_size = 3;
    else if (condition_kind == 3 || condition_kind == 4)
        condition_size = 2;
    else if (condition_kind == 1)
        condition_size = 1;
    
    if(result_kind == 2)
        result_size = 3;
    else if (result_kind == 3 || result_kind == 4)
        result_size = 2;
    else if (result_kind == 1)
        result_size = 1;

    char item_num = 3 + condition_size * condition_num + result_size * result_num;

    target_list.resize(item_num);

    char one = item_head.attribute_kind;

    char two = condition_kind << 4;
    two |= result_kind;

    char three = condition_num << 4;
    three |= result_num;

    char four;

    *((char *)ptr) = one;
    *((char *)ptr + 1) = two;
    *((char *)ptr + 2) = three;
    *((char *)ptr + 3) = four;

    //没有神经元锁定
}

//通用属性写入
void general_attribute_put(
    Attribute_Head attribute_head, vector<int>& target_context_list,
    vector<General_Condition>& general_condition_list, vector<General_Result>& general_result_list)
{
    attribute_head_put(attribute_head, target_context_list);
    
    char condition_kind;
    char result_kind;

    char condition_num = general_condition_list.size();
    char result_num = general_result_list.size();

    int* ptr = target_context_list.data();
    *(ptr + 1) = 0; 
    *(ptr + 2) = 0;
    ptr += 3;

    switch(condition_kind)
    {
        case 1:
        {
            for(int a = 0; a < condition_num; a++)
            {
                general_condition_list[a].image_condition;

                ptr += 3;
            }
        }
        break;
        case 2:
        {
            for(int a = 0; a < condition_num; a++)
            {
                general_condition_list[a].number_condition;

                ptr += 3;
            }
        }
        break;
        case 3:
        {
            for(int a = 0; a < condition_num; a++)
            {
                general_condition_list[a].time_condition;

                ptr += 3;
            }
        }
        break;
        case 4:
        {
            for(int a = 0; a < condition_num; a++)
            {
                general_condition_list[a].text_condition;

                ptr += 3;
            }
        }
        break;
        case 5:
        {
            for(int a = 0; a < condition_num; a++)
            {
                general_condition_list[a].concept_condition;

                ptr += 2;
            }
        }
        break;
        case 6:
        {
            for(int a = 0; a < condition_num; a++)
            {
                general_condition_list[a].action_conditon;

                ptr += 4;
            }
        }
        break;
    }

    switch(result_kind)
    {
        case 1:
        {
            for(int b = 0; b < result_num; b++)
            {
                general_result_list[b].image_result;

                ptr += 3;
            }
        }
        break;
        case 2:
        {
            for(int b = 0; b < result_num; b++)
            {
                general_result_list[b].number_result;

                ptr += 3;
            }
        }
        break;
        case 3:
        {
            for(int b = 0; b < result_num; b++)
            {
                general_result_list[b].time_result;

                ptr += 3;
            }
        }
        break;
        case 4:
        {
            for(int b = 0; b < result_num; b++)
            {
                general_result_list[b].text_result;

                ptr += 3;
            }
        }
        break;
        case 5:
        {
            for(int b = 0; b < condition_num; b++)
            {
                general_result_list[b].concept_result;

                ptr += 2;
            }
        }
        break;
        case 6:
        {
            for(int b = 0; b < condition_num; b++)
            {
                general_result_list[b].belief_result;

                ptr += 4;
            }
        }
        break;
        case 7:
        {
            for(int b = 0; b < condition_num; b++)
            {
                general_result_list[b].manner_result;

    
                ptr += 3;
            }
        }
    }

    //没有在节点添加连接的环节

}

// 被动记录属性
struct Passive_Link_Attribute
{
    char kind_is_passive = 10;
    char link_attribute_kind;
    char b;
    char c;
    ID target_id;
};
// 2*4字节，神经元架构

//
void passive_link_put(Passive_Link_Attribute passive_link_attritube, 
    vector<int>& target_list)
{
    target_list.resize(2);
    int* ptr = target_list.data();
    *((char*)ptr) = passive_link_attritube.kind_is_passive;
    *((char*)ptr + 1) = passive_link_attritube.link_attribute_kind;
    *(ptr + 1) = passive_link_attritube.target_id;
}


// 神经元改写任务队列
unordered_set<ID> waiting_modify_neuro_search;
deque<ID> waiting_modify_neuro;
deque<vector<int>> waiting_modify_context;

// 待写队列加载函数，未完成
void modify_neuro_queue_load(ID target, vector<int> context)
{
    if (waiting_modify_neuro_search.count(target) == 1)
    {
        // 已有任务下
        // 没写好
        // 怎么增加任务
    } else {
        // 未有任务
        waiting_modify_neuro.push_back(target);
        waiting_modify_context.push_back(context);
        waiting_modify_neuro_search.insert(target);
    }
}

// 神经元新建，返回新建节点id
ID new_neuro_create(char neuro_kind/* 1 2 3 */, Neuro_Desc neuro_desc)
{
    ID node_id;

    if (FREE_ID_NUM > 0)
    {
        FREE_ID_NUM--;
        node_id = FREE_ID_LIST.back();
        FREE_ID_LIST.pop_back();
    }
    else
    {
        // 查找此时的最新未使用节点
        node_id = NEWIST_USEFUL_ID;
        NEWIST_USEFUL_ID += 1;
    }

    INDEX idx = pack_position_insert(node_id, 1); // 新插一个包

    // 填写神经元头
    Neuro_Head_Attribute neuro_head;
    neuro_head.neuro_kind = neuro_kind;

    int *ptr = Neuro_Pack_Storage[idx].attribute_item;
    *(Neuro_Head_Attribute*)ptr = neuro_head;

    // 描述类型填入
    ptr += 1;
    if(neuro_kind == 1)
    {
        Neuro_Image_Desc desc = neuro_desc.image_desc;
        *(Neuro_Image_Desc*)ptr = desc;
        
    } else if(neuro_kind == 2) {
        
        Neuro_Text_Desc desc = neuro_desc.text_desc;
        *(Neuro_Text_Desc*)ptr = desc;

    } else if(neuro_kind == 3) {
        
        Neuro_Concept_Desc desc = neuro_desc.concept_desc;
        *(Neuro_Concept_Desc*)ptr = desc;
    }

    return node_id;
} // 函数结束

// 神经元删除，未完成
void neuro_delete(unsigned int node_id)
{
    // 擦除所有被动链接与上级节点、下级节点连接，未完成

    FREE_ID_NUM++;
    FREE_ID_LIST.push_back(node_id);
}

// 神经元扩容
char neuro_size_up(unsigned int target_id, unsigned char level)
{
    //但是怎么去确定是否扩容
    //毕竟小于4级时扩容不消耗存储空间

    INDEX ori_idx;

    if (Pack_Vector_Index_Find.count(target_id) != 0)
        ori_idx = Pack_Vector_Index_Find[target_id];
    else
        return -1;

    char curr_pack_size = Neuro_Pack_Record_Storage[ori_idx].pack_size;
    char more_pack_size = level - curr_pack_size;

    if (more_pack_size < 0)
        return -2;

    //提供空位
    INDEX new_idx = pack_position_insert(target_id, level);

    //转移内容
    for(int a = 0; a < curr_pack_size; a++)
    {
        Neuro_Pack_Storage[new_idx + a] = Neuro_Pack_Storage[ori_idx + a];
        Neuro_Pack_Record_Storage[new_idx + a] = Neuro_Pack_Record_Storage[ori_idx + a];
    }

    // 改头部数据
    char *head_ptr = (char *)Neuro_Pack_Storage[new_idx].attribute_item;
    head_ptr++;
    *head_ptr = level;
    head_ptr++;
    *(short *)head_ptr += more_pack_size * 256;

    return 1;
}

// 神经元条目删除，未完成，被动连接未删除，属性描述未填改
char neuro_item_delete(ID target,
    unsigned short item_order, unsigned char delete_num)
{
    // 查找节点位置
    INDEX vec_pos = pack_index_find(target);

    if (vec_pos == -1)
        return 0;

    int* ptr = Neuro_Pack_Storage[vec_pos].attribute_item;

    if (ptr == 0) // 未载入包，查找失败
        return -1;

    char* pack_state = &Neuro_Pack_Record_Storage[vec_pos].pack_state;

    unsigned char pack_size = Neuro_Pack_Record_Storage[vec_pos].pack_size;
    unsigned short used_item_num = *((unsigned short *)(ptr) + 1);

    if (item_order > used_item_num) // 填位置错，不应该
        return -2;

    if (*pack_state != 2)
        return -3;

    *pack_state = 5;

    // 修改原描述，更新头部数据
    *((unsigned short *)(ptr) + 1) -= delete_num;

    int *delete_ptr = ptr;
    ptr += delete_num;

    // 覆盖指定内容
    for (unsigned short curr_item = item_order + delete_num; curr_item <= used_item_num; curr_item++)
    {
        *delete_ptr = *ptr;

        delete_ptr += 1;
        ptr += 1;
    }

    *pack_state = 2;

    return 1;
}

// 神经元属性添加，没有改描述信息
char neuro_attribute_write(
    ID target_ID, vector<int> item_context,
    unsigned short position, bool add_or_insert/* 中间插入0，末尾添入1 */ )
{
    // 查找节点位置
    int* ptr = node_find(target_ID);

    if (ptr == 0)
    { // 查找失败，因为没有载入包
        // 加载包
        add_to_Will_Read_Neuro_Queue(target_ID);

        // 加入神经元填写任务队列
        modify_neuro_queue_load(target_ID, item_context);
        return 0;
    }

    int *first_ptr = ptr;
    char *pack_state = ((char *)(first_ptr - 15) + 1);

    if (*pack_state != 2)
        return 0;

    *pack_state = 4;
    char pack_size = *((char *)(first_ptr) + 1);
    unsigned short used_item_num = *((short *)(first_ptr) + 1);

    int item_context_size = item_context.size();

    // 1、可写空址搜寻
    if ((pack_size * 256 - 16 - used_item_num) > item_context_size)
    {
        // 不通过，空间不足
        // 加入神经元填写任务队列
        vector<int> context; // 待
        modify_neuro_queue_load(target_ID, context);
        return 0;
    }

    // 2、录入属性信息
    *((short *)first_ptr + 1) += item_context_size;

    char curr_pack_order = 0;

    unsigned short curr_order;

    bool have_more_pack = 0;

    if (pack_size > 1)
        have_more_pack = 1;
    

    // 3、正式录入
    if (add_or_insert == 1)
    {
        // 追加条目

        // 找到读写位置
        ptr += used_item_num;

        // 开始追加
        for (int single_item : item_context)
        {
            // 不连续包，连续性侦测
            *ptr = single_item;
        }

    } else if (add_or_insert == 2) {

        // 挪移条目

        char pack_size = *((char *)first_ptr + 1);
        unsigned short used_item_num = *((short *)first_ptr + 1);

        int insert_pos = position;

        // 开始挪移
        int *write_ptr;
        int *end_ptr;
        int middle_item_num = used_item_num - insert_pos;

        // 挪移条目
        if (have_more_pack == 0)
        {
            // 找到位置
            write_ptr = first_ptr + used_item_num;
            end_ptr = first_ptr + used_item_num + item_context_size;

            for (int q = 0; q < middle_item_num; q++)
            {
                *end_ptr = *write_ptr;
                end_ptr--;
                write_ptr--;
            }
        }

        // 4、写入条目
        ptr = first_ptr + insert_pos;

        for (int single_item : item_context)
        {
            *ptr = single_item;
            ptr++;
        }

    }

    // 录入完成
    *pack_state = 2;

    return 1;
}

// 整合神经元属性添加
inline void Simple_Neuro_Attribute_write(unsigned int target_id, 
    unsigned short position, bool add_or_insert,// 中间插入0，末尾添入1
    Attribute_Head attribute_head, 
    vector<General_Condition>& general_condition_list, vector<General_Result>& general_result_list)
{
    vector<int> add_item;
    vector<int> passive_item;

    Passive_Link_Attribute passive_link_attribute;
    passive_link_attribute.link_attribute_kind = attribute_head.attribute_kind;
    passive_link_attribute.target_id = target_id;

    general_attribute_put(attribute_head, add_item, general_condition_list, general_result_list);
    passive_link_put(passive_link_attribute, passive_item);

    neuro_attribute_write(target_id, add_item, 0, 1);
    neuro_attribute_write(general_result_list[0].image_result.related_id, passive_item, 0, 1);
}


// 图像相关

// rgb像素值
struct RGB_Unit
{
    unsigned char r, g, b;
};

// 二维点
struct point_2d
{
    short x, y;
};

struct Point_2d_Equal
{
    bool operator()(const point_2d &a, const point_2d &b) const
    {
        return a.x == b.x && a.y == b.y;
    }
};

struct Point_2d_Hash
{
    size_t operator()(const point_2d &p) const
    {
        return hash<int>()(p.x) ^ (hash<int>()(p.y) << 1);
    }
};

inline bool point_less(const point_2d &a, const point_2d &b)
{
    if (a.x != b.x)
        return a.x < b.x;
    return a.y < b.y;
}


struct VectorUint32_tHash
{
    size_t operator()(const vector<uint32_t> &v) const noexcept
    {
        uint64_t h = 1469598103934665603ULL; // FNV-1a offset

        for (uint32_t x : v)
        {
            uint64_t z = static_cast<uint64_t>(x);
            h ^= z;
            h *= 1099511628211ULL; // FNV prime
        }

        return static_cast<size_t>(h);
    }
};

struct VectorUint32_tEq
{
    bool operator()(const vector<uint32_t> &a,
        const vector<uint32_t> &b) const noexcept
    {
        return a == b; // 实现逐元素比较
    }
};


// 现象相关 统计 模拟 因果

// 节点自特性
struct Node_ImageAttribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Image_Attribute = 1;
    char standard_size; // 视角大小

    short x, y; // 图中定位点位置

    int block_num = 0;  // 占据格数
    int contain_distance = 0; // 内部包含的距离总和
};
//4*4字节

struct Node_TextAttribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Text_Attribute = 2;
    char non;

    INDEX idx = 0;
    int block_num = 0;
};
//3*4字节

struct Node_TimeAttribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Time_Attribute = 3;

    char time_range;    // 时间区域(-8~8)，0是同时，1是从此刻至一尺度时间，2是一尺度至二尺度，类推
    char time_scale;    // 时间规模，0(无规模仅模糊方向)、1(0.1秒)、2(0.2秒)、3(0.4秒)、4(0.8秒)，类推
    char time_logic = 0;    // 对象存在1，对象不存在2

    int self_time_front = 0; // 原型long long而来的时间，对齐需要
    int self_time_back = 0; // 等同于模型时间上的位置
};
//4*4字节

struct Node_NumberAttribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Number_Attribute = 4;
    char logic; // node_number1 Probability2
    
    int number_I = 0;
    int number_II = 0;
};
//3*4字节

struct Node_MotionAttribute
{
    char curr_is_use = 1;
    char kind_is_self_attribute = 1;
    char kind_is_Node_Motion_Attribute = 5;
    char non;

    char action_order; // 行动顺序
    char action_kind; // 行动类型，鼠标1，键盘2，文本传回3，文本显示4，窗口隐藏5，窗口显示6
    unsigned char vk; // 键盘可选，键码
    char mouseData; // 鼠标可选，滚轮 1格 = 120

    short x, y; // 鼠标可选，自身坐标
    
    unsigned int dwFlags; // 通用，行为标志
};
//4*4字节

// 链接属性
struct Object_LinkAttribute
{
    char curr_is_use = 1;
    char Link_Attribute = 0; // 自我属性1 链接节点2、(所属场域3、意图需求4、)所需特征5
    char Link_Kind = 0; /* 下源1 上成2 原因3 结果4 抑制5 无需6 数目统计上7 数目统计下8 
        存在0* 不存在1* 模拟性2* 行动性3*(下个行动31 上个行动32 前提行动33 后接行动34) 连接0** 被连接1** */
    char connect_direction = 0;
    
    ID Link_ID;
    INDEX Link_Idx = 0; // 节点下标
    float Link_Value = 1; // 属性值，因果概率
};
//4*4

// 图像模拟属性
struct Simulate_ImageAttribute
{
    char curr_is_use = 1;
    char kind_is_simulate = 5;
    char kind_is_Simulate_Image = 1;
    char is_joint = 0; // 连带为1

    char direction;
    char direction_scale = 3;
    char distance;
    char distance_scale = 3;

    char logic;
    char related_scale;
    char a;
    char b;

    ID related_id;
};
// 4*4字节

// 文本模拟属性
struct Simulate_TextAttribute
{
    char curr_is_use = 1;
    char kind_is_simulate = 5;
    char kind_is_Simulate_Text = 2;
    char is_joint = 0; // 连带为1

    char left_distance = 1;
    char right_distance = 1;
    unsigned char distance_scale = 4;
    char logic;

    ID target_id;
};
// 3*4字节

// 时间模拟属性
struct Simulate_TimeAttribute
{
    char curr_is_use = 1;
    char kind_is_simulate = 5;
    char kind_is_Simulate_Time = 3;
    char is_joint = 0; // 连带为1

    char time_range;
    char time_scale;
    char logic;
    char item_detail = 0;

    ID related_id;
};
//3*4字节

// 数量模拟属性
struct Simulate_NumberAttribute
{
    char curr_is_use = 1;
    char kind_is_simulate = 5;
    char kind_is_Simulate_Number = 4;
    char is_joint = 0; // 连带为1

    char logic; // 
    char detail; // 作概率统计1、作数量统计2、作数量达标下限3、作数量达标上限4、作数量区间5 

    int number_I = 0; // active_stat激活、统计的次数
    int number_II = 0; // realize_detect实现、探测的次数
}; //4*4字节，神经元条目


// 关注对象，生成时检索
struct Focus_Object
{
    char kind; // 关注1 需求2 需求汇总3 匹配4 无需5 （抑制6） 待记录7
    INDEX target_idx;
};

// 后统计结果待记录入神经元
struct Stat_Wait_Add_To_Neuro
{
    //在每次检索目标神经元时，检查有无后续追加的统计数量，若有，直接加上
    char is_use = 1;
    char operation;// 描述(1*)在item确定位置  属性(2*)
    char number = 0;
    unsigned char item_order;
    
    ID neuro_id;

    Neuro_Link_Attribute record_item; // 定位要增加统计数量的条目
};
//

// 待激活神经元
struct Wait_Active_Neuro
{
    char curr_is_use = 1;
    ID id;
};

// 注意对象
struct Attention_Object
{
    char curr_use = 1;
    char is_id_or_idx = 0;

    int value = 0;
    uint32_t id_or_idx = 0; // 

    // 反馈对象，一般是一些需求与填写的任务
    vector<INDEX> feedback_object;
};


// 需求一个对象
struct Require_ID
{
    char require_is_id = 1; // 10以上为连带前列
    char require_kind; //
    /* retrieve识别1* 
    检索生成构造目的10 解释目标态度属性11 行动连接性探测12
    */
    /* model建模2* 
    文本对象性建模21 
    */
    /* construct构造3* ～ 4*
    构造下级与对应的节点31    排列文本构造需求节点32    构造为图像节点33     外部追求构造34
    */
    char require_level = 0; // 自生需求1 根源需求2
    char is_a_id_or_idx; // 1有神经元id、2为网络节点

    ID require_id;

    int require_value = 0;
    int statisfy_value = 0;
};
//4*4字节

// 需求一种场景属性
struct Require_Scene
{
    char require_is_scene = 2; // 10以上为连带前列
    char require_kind; // 相对性+0 绝对性+100
    /*
    retrieve识别1*
    model建模2*
    construct构造3*
    */
    char require_scene_kind; // 自身0 空间属性/区域1 数量属性/区域2 时间属性/区域3 文本属性/区域4
    char require_level; // 

    short range_I; // 空间左界 时间前界
    short range_II; // 空间右界 时间右界
    short range_III; // 空间上界
    short range_IV; // 空间下界

    INDEX scene_idx;
    int require_value = 0;
    // int statisfy_value = 0;
};
// 4*4字节


// 需求对象
union Require_Object
{
    Require_ID the_ID;
    Require_Scene the_Scene;
};


//节点间链接
union Variable_Attribute
{
    // 自身属性
    Node_ImageAttribute node_image_attribute;
    Node_TimeAttribute node_time_attribute;
    Node_TextAttribute node_text_attribute;
    Node_NumberAttribute node_number_attribute;
    Node_MotionAttribute node_motion_attribute;

    // 链接属性
    Object_LinkAttribute object_link_attribute;

    // 模拟需求属性
    Simulate_ImageAttribute simulate_image_require;
    Simulate_TimeAttribute simulate_time_require;
    Simulate_TextAttribute simulate_text_require;
    Simulate_NumberAttribute simulate_number_attribute;

    // 需求属性
    Require_ID the_ID;
    Require_Scene the_Scene;
};

Node_ImageAttribute filler_attribute;


// 通用认知节点
struct General_Cognition_Node
{
    //
    // 固定属性区
    bool is_use = 1;
    char now_occupy = 0;
    char node_kind; // 现实0，模拟1，不存在(未生成)3，不需要4，检索1*，新生2*
    char self_from; // 图象1，时间线2，文本3，行动，后果4(可变概率)，概念？,数量统计5

    unsigned char node_layer;
    unsigned char rough_spare_size; // 大致的剩余空间 (原空间/8)-2
    char node_calu_state = 1; // 一个运算的辅助量
    char stability_num;

    char was_active = 0;

    int node_attention = 0; // 注意力值
    ID self_id = 0;
    INDEX Belong_Scene = 0;

    int component = 0; // 一个运算的辅助量

    float complete_or_probability = 1; // 完整度 或 存在概率
    int have_num = 0; // 分子表示
    int total_num = 0; // 分母表示

    float predict_stability = 0;

    // 自身需求
    int recognize_require = 0; // 识别需求 预测对象 不清楚度
    int model_require = 0; // 建模需求 理解出现逻辑 主动创造知识
    int construct_require = 0; // 构造需求 大概用在思维对象的成分构造 比如追求的过程思考规划 

    int identify_require = 0; // 对应需求，一种高级建模需求

    // 快速查找属性
    Variable_Attribute self_attribute[3] = {filler_attribute, filler_attribute, filler_attribute};

    //
    // 链接区
    vector<Variable_Attribute> Variable_list;
};
//11*4 + 6*4 + n*4*4


Neuro_Image_Item filler_condition;
Neuro_Image_Item filler_result;

// 节点匹配生成
struct Generate_Match
{
    char attritube_kind;

    char need_condition_num;
    char not_condition_num;
    char node_num = 0;

    INDEX every_node_from[5];
    General_Condition every_condition[4] = {filler_condition, filler_condition, filler_condition, filler_condition};
    
    General_Result infer_result_id[4] = {filler_result, filler_result, filler_result ,filler_result};
};

// 要求无
// struct UnNeed_Have
// {
//     char kind;         // 节点 匹配
//     INDEX node_idx; // 所支撑节点
// };

// 聚合抑制，大概转到注意力与需求抑制
// 使用注意力转移会更好
// 需求抑制 认知抑制 构造抑制
// struct Restrain_Concept
// {
//     char source_num;
//     INDEX causal_restrain_source[5];
//     vector<INDEX> effect_idx;
// };


// 因果抑制，因果统计时使用
struct Casual_Restrain
{
    INDEX Restrain_Source;
    ID Restrain_Target;

    float Restrain_Rate;
};



// 区域属性存储
struct Scene_ImageAttribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Image = 21;

    short left, right, bottom, top;
};
// 3*4字节

struct Scene_TextAttribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Text = 22;

    short left, right;
};
// 2*4字节

struct Scene_TimeAttribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Time = 23;
    
    int begin_time_front;
    int begin_time_end;

    int durable_over_time; // 占据的时间
};
// 4*4字节

struct Scene_ProbabilityAttribute
{
    char curr_is_use = 1;
    char Self_Scene_Attribute_Is_Probability = 24;

    char kind; // source1 next2
    unsigned char current_scene_layer;
    float probability; // source1 next2 self3
    INDEX station_idx;
};
//

struct Scene_MotionAttribute
{
    char curr_is_use = 1;
    char kind = 2;
    char Self_Scene_Attribute_Is_Motion = 5;
    char last1_or_curr2;

    int time_front; // last_operate
    int time_end; // last_operate

    INDEX motion_idx;
};

//

// 链接场景属性
struct Scene_Related
{
    char normal_use = 1;
    char kind;                  // 连接场景1 场景属性2* 目标相关1*
    unsigned char related_kind; // 图像1 文本2 心理3 界面4、行动探测5 现实1* 混杂2* 想象3*、组成1** 分解2**
    INDEX scene_idx;
    float related_value;
};
// 3*4字节

//
union Scene_Object
{
    Scene_ImageAttribute scene_image_attribute;
    Scene_TextAttribute scene_text_attribute;
    Scene_TimeAttribute scene_time_attribute;
    Scene_ProbabilityAttribute scene_probability_attribute;
    Scene_MotionAttribute scene_motion_attribute;

    Scene_Related relative_Scene;
};


struct value_sort_unit {
    INDEX higher_one = 0;   /* > */
    INDEX lower_one = 0; /* <= */
    int value = 0;
    INDEX target_idx = 0;
};

value_sort_unit value_sort_unit_a;

//快速排序表
class Advanced_Value_Target_Sort
{
    public:

    vector<value_sort_unit> fast_enter_list = {value_sort_unit_a};
    int enter_gap = 0;

    int change_number = 0;
    vector<value_sort_unit> inside_important_sort = {value_sort_unit_a};
    vector<INDEX> Blank_Idx_List;

    //1
    INDEX find_a_value_pos(int value)//the_first<=
    {
        INDEX check_this = 1;

        for( ; check_this < fast_enter_list.size(); check_this++)
        {
            if(fast_enter_list[check_this].value > value) {
                continue;
            } else {
                check_this--;
                break;
            }
        }

        if(fast_enter_list.size() != 1)
            check_this = fast_enter_list[check_this].target_idx;
        else return 0;

        while(inside_important_sort[check_this].value > value)
        {
            INDEX lo = inside_important_sort[check_this].lower_one;
            
            if(lo != 0)
                check_this = lo;
            else
                break;
        }

    return check_this;
    }

    //2
    void insert_a_unit(value_sort_unit insert_unit)
    {
        //
        INDEX lower_one = find_a_value_pos(insert_unit.value);

        INDEX insert_position;
        if( !Blank_Idx_List.empty() )
        {
            insert_position = Blank_Idx_List.back();
            Blank_Idx_List.pop_back();
        } else {
            insert_position = inside_important_sort.size();
            inside_important_sort.push_back(insert_unit);
        }


        //这种查询的结构，允许通过第0位查询最大最小值
        INDEX upper_one = inside_important_sort[lower_one].higher_one;

        inside_important_sort[upper_one].lower_one = insert_position;
        inside_important_sort[lower_one].higher_one = insert_position;

        inside_important_sort[insert_position].higher_one = upper_one;
        inside_important_sort[insert_position].lower_one = lower_one;

        change_number += 1;

        if(change_number > 2*(enter_gap + 1) )
            reset_enter();
    }

    //3
    void delete_a_unit(value_sort_unit delete_unit)
    {
        INDEX pos = find_a_value_pos(delete_unit.value);

        if(inside_important_sort[pos].value == delete_unit.value)
        {
            INDEX last_one = inside_important_sort[pos].higher_one;
            INDEX next_one = inside_important_sort[pos].lower_one;

            inside_important_sort[last_one].lower_one = next_one;
            inside_important_sort[next_one].higher_one = last_one;

            Blank_Idx_List.push_back(pos);

            fast_enter_list;
        }

        change_number -= 1;

        if(change_number < -2*(enter_gap - 1) )
            reset_enter();
    }

    //4
    bool change_a_unit(value_sort_unit origin_unit, value_sort_unit change_unit)
    {
        INDEX possible_idx = find_a_value_pos(origin_unit.value);

        while(inside_important_sort[possible_idx].target_idx
            != origin_unit.target_idx)
        {
            possible_idx = inside_important_sort[possible_idx].lower_one;

            if(inside_important_sort[possible_idx].value != origin_unit.value)
            {
                return 0;
            }
        }

        inside_important_sort[possible_idx].value = change_unit.value;

        return 1;
    }

    //5
    void reset_enter()
    {
        int ture_numder = inside_important_sort.size() - Blank_Idx_List.size();

        if( ture_numder >= (enter_gap+1)*(enter_gap+1) )
        {
            int old_enter_gap = enter_gap;

            enter_gap += 1;

            int current_No = 1;

            INDEX target_idx = fast_enter_list[1].target_idx;

            int write_idx = 2;

            //1、
            for( ; write_idx < fast_enter_list.size(); write_idx++)
            {
                for(int w = 0 ; w < enter_gap; w++)
                {
                    target_idx = inside_important_sort[target_idx].target_idx;
                    current_No++;
                }

                fast_enter_list[write_idx].target_idx = target_idx;
            }

            int number_of_this_unit = 0;

            //2、
            while( current_No < ture_numder )
            {   
                for(int q = 0; q < enter_gap; q++)
                {
                    target_idx = inside_important_sort[target_idx].target_idx;
                    current_No++;
                    number_of_this_unit++;
                }

                if(number_of_this_unit == enter_gap-1 )
                {
                    value_sort_unit new_unit;
                    new_unit.target_idx = target_idx;
                    
                    fast_enter_list.push_back(new_unit);
                    number_of_this_unit = 0;
                }
            }

        } else if (ture_numder <= (enter_gap-1)*(enter_gap-1) ) {

            int old_enter_gap = enter_gap;

            enter_gap -= 1;

            int current_No = 1;

            INDEX target_idx = fast_enter_list[1].target_idx;

            int write_idx = 2;

            int number_of_this_unit = 0;

            //1、
            for( ; write_idx < fast_enter_list.size() && current_No < ture_numder; write_idx++)
            {
                for(int w = 0 ; w < enter_gap; w++)
                {
                    target_idx = inside_important_sort[target_idx].target_idx;
                    current_No++;
                    number_of_this_unit++;
                }

                if(number_of_this_unit == enter_gap-1)
                {
                    fast_enter_list[write_idx].target_idx = target_idx;
                    number_of_this_unit = 0;
                }
            }

            //2、
            while(write_idx <= fast_enter_list.size())
            {
                fast_enter_list.pop_back();
            }


        }
    }
};


// 通用认知场景
struct General_Scene
{
    bool curr_use = 1;
    char scene_kind; // 图像1 文本2 认知3 界面4 行动连接5 现实1* 混杂2* 想象3*

    int importance = 0;
    int total_invest_resource = 0;

    int attention = 0;

    int retrieve_require = 0;
    int model_require = 0;
    int construct_require = 0;

    // 内部事件存储
    vector<INDEX> All_have_node_idx_list;
    unordered_map<ID, vector<INDEX>> Id_find_node_idx; // id查找存储下标（共享存储区）

    // 本地节点
    vector<General_Cognition_Node> Cognition_local_node_list;
    vector<INDEX> Free_cognition_local_node_idx;
    unordered_map<ID, vector<INDEX> > Id_to_local_cognition_node;

    unordered_set< vector<ID>, VectorUint32_tHash, VectorUint32_tEq > Cognition_Combo_Unordered;

    vector<INDEX> High_attention_node_list;
    vector<INDEX> Free_high_attention_idx;

    // 相关场景属性
    vector<Scene_Related> Scene_related_list;

    unordered_map<long long , INDEX> Info_to_scene;

    // 综合查找
    unordered_map<ID, vector<Focus_Object> > Focus_object_check;

    vector<Attention_Object> Attention_object_list; // 关注、忽略的注意力对象
    vector<INDEX> Free_attention_object_index;

    vector<Generate_Match> Generate_match_list; // 生成匹配
    vector<INDEX> Free_generate_match_idx;

    vector<Require_Object> Require_Object_List; // 目标需求
    vector<INDEX> Free_require_object_idx;
    Advanced_Value_Target_Sort Require_sort;

    //统计预测时的方向
    unordered_map< long long, INDEX > every_4_time_event;
    unordered_map< long long, INDEX > every_16_time_event;
    unordered_map< long long, INDEX > every_64_time_event;
};


// 模型输出行动
struct Model_Output_Action
{
    char action_order; // 行动顺序
    char action_kind; // 行为类型，鼠标行为1，键盘行为2，文本传回3，文本显示4，窗口隐藏5，窗口显示6
    unsigned char vk; // 键盘可选，键码
    char mouseData; // 鼠标可选，滚轮  *120/格

    short x, y; // 鼠标可选，坐标 精确偏移量 模糊偏移量
    
    unsigned int dwFlags; // 通用，行为标志
}; // windows版本键鼠输出，3*4字节


// 图像属性


// 线段实体
struct Line_Object
{
    char kind; // 边界 内部 复合 杂色 形态
    unsigned char size;
    
    unsigned char red;      // 色彩
    unsigned char green;
    unsigned char blue;

    char direction; // 方向
    short length;   // 长度

    int attention_value = 0;

    int x_sum = 0;
    int y_sum = 0;

    int block_num;
    float reward_rate;
    int reward_value;

    float abs_diff_value;
    float sum_diff_value;
    float ave_diff_rate;

    point_2d middle_coordinate; // 中部位置
    point_2d base_point;        // 起始位置
    
    vector<point_2d> Inside_Point;
    //vector<INDEX> Inside_Point;
};

struct Line_Object_II
{
    char line_kind; // 边界 内部 复合 杂色 形态
    unsigned char size;
    
    unsigned char red;
    unsigned char green;
    unsigned char blue;

    char direction;
    short length;

    float quality;
};


// 图像粗略格块
struct Image_Colour_Block
{
    char proc_stage = 0; // 点处理类型；未观测0，团块内点1，边界点2
    char diff_colour = 0b00000000; // 异值像素点的方向

    // 颜色相关
    unsigned char ave_r, ave_g, ave_b;

    unsigned char un_explain_line = 0; // 线段构造需求
    char have_node_num = 0;
};


// 空间粗略图
struct Space_Rough_Map
{
    char is_init = 0;
    char standard_size; // 尺寸 1 2 4 8
    
    unsigned short self_width, self_height; // 宽高

    //内部像素数统计
    vector<int> colour_number_distribution; // 8*8*8 = 512
    vector<int> colour_x_distribution; // 512 = num
    vector<int> colour_y_distribution; // 512 = num

    vector<Image_Colour_Block> Colour_block_list;
};


// 空间需求图
struct Space_Require_Map
{
    char record_distance = 1; // 1、2、4、8、16、32
    vector< vector<INDEX> > Node_space_record;

    int total_require_valve = 0;
    char require_distance = 1; // 1、2*2=4、4*4=16、8*8=64、16*16=256、32*32 = 1024
    vector< vector<int> > Require_map; // 区域需求 汇总率为8倍
};


// 格块关注
struct Rigion_Value_Stat
{
    unsigned short height;           // 垂直单位数量
    unsigned short width;            // 水平单位数量
    unsigned short height_unit_size; // 垂直区域单位大小
    unsigned short width_unit_size;  // 水平区域单位大小

    vector<int> attention_unit_list;

    //sqrt{block_number}
    //中心
};

//
struct Space_Attend_Attention
{
    char is_use = 1;
    char is_region = 1;
    unsigned short left, right, top, bottom;

    int attention_value = 0;
};

//
struct Colour_Attend_Attention
{
    char is_use = 1;
    char is_connect = 0;
    char is_colour = 1;

    unsigned char red_min;
    unsigned char red_max;

    unsigned char green_min;
    unsigned char green_max;

    unsigned char blue_min;
    unsigned char blue_max;

    int attention_vlaue = 0;
};

//
struct Target_Attend_Attention
{
    char is_use = 1;
    char is_connect = 0;

    ID id;
    int attention_vlaue = 0;
};

//
union Attend_attention
{
    Space_Attend_Attention space_object;
    Colour_Attend_Attention colour_object;
    Target_Attend_Attention target_object;
};

// 图像匹配
struct Image_Match
{
    char generate_kind = 0; // 仅统计0 生成图像1 生成概念2
    char total_need = 0;
    char node_num;
    
    ID result_generate_id; // 生成的结果，或者是统计的源头
    INDEX node_idx_from_list[5];
    Neuro_Image_Item need_condition_list[4];
};


// 完整图形分析
struct Image_Scene
{
    char curr_use = 1;
    char is_init_recognize = 0; // 初始化
    char is_lock_occupy = 0;
    char model_output_action_num = 0;

    unsigned short width, height; // 宽高
    
    INDEX last_map = 0;
    INDEX next_map = 0;

    int attention = 0;
    int sum_nature_attention = 0;   // 总区域变化和继承

    int sum_retrieve_require = 0;
    int sum_model_space_require = 0;
    int sum_model_time_require = 0;
    int sum_construct_require = 0;

    float retrieve_add_rate = 1;
    float model_space_add_rate = 0.5;
    float model_time_add_rate = 0.5;
    float construct_add_rate = 0;

    int graph_node_num;

    // 来源时间
    long long input_time;

    Model_Output_Action Current_output_action[5];

    // 原图
    vector<RGB_Unit> RGB_map;

    // 自然注意力区域
    vector<Rigion_Value_Stat> Block_attention_list; // 区块注意力 由像素点与粗区块形成
    vector<Rigion_Value_Stat> Area_attention_list;
    /* 区域注意力 更大 8倍汇总率 用于确定观察位置*/
    
    vector< vector<int> > Retrieve_require_list;
    vector< vector<int> > Model_require_list; // 区域需求 8倍汇总率

    // 附加注意力
    vector<Attend_attention> Append_attention;

    // 图像解释覆盖
    char space_rough_view_number = 0;
    Space_Rough_Map Space_rough_view[4];

    char space_retrieve_require_view_number = 0;
    Space_Require_Map Space_retrieve_require_view[6];

    // 图像节点存储
    vector<INDEX> Image_overall_node_list; // 当前场景 全体节点
    unordered_map<ID, vector<INDEX> > Id_find_overall_index; // id查找图像节点下标

    vector<General_Cognition_Node> Image_local_node_list;
    vector<INDEX> Free_image_local_node_idx;
    unordered_map<ID, vector<INDEX> > Id_find_local_index;

    // 图像聚合去重
    unordered_set<vector<INDEX>, VectorUint32_tHash, VectorUint32_tEq> Image_combo_unordered;

    unordered_map<ID, vector<Focus_Object> > Find_id_of_focus_list;

    // 图像聚合匹配
    vector<Image_Match> Image_match_list;
    vector<INDEX> Free_image_match_index;
    unordered_map<ID, vector<INDEX>> Find_image_match;

    // 图像需求匹配
    vector<Require_Object> Require_object_list;
    vector<INDEX> Free_require_idx;

    // 相关场景属性
    vector<Scene_Related> Related_scene_list;
};


// 文本相关


// 文本匹配
struct Text_Match
{
    char generate_kind = 0; // 仅统计0 生成文本1 生成概念2
    char need_condition_num = 0;
    char node_num;
    
    ID infer_sustain_id; // 生成的结果，或者是统计的源头
    INDEX node_idx_from_list[5];
    Neuro_Image_Item need_condition_list[4];
};

// 字符推理上下行网络
struct Text_Scene
{
    char is_use = 1;
    char source_kind; // 1输入获取 2界面输入 3内部生成
    char have_init = 0;
    char Retrieval_Density = 8;    // 4、8、16

    char scene_layer = 0; // 模拟量
    char scene_order = 0; // 模拟量
    
    int attention;
    int text_derive_attention;

    int sum_retrieve_require = 0;
    int sum_model_require = 0;
    int sum_identify_require = 0;
    int sum_construct_require = 0;

    int original_text_size = 0;

    float retrieve_add_rate = 1;
    float model_add_rate = 0.5;
    float construct_add_rate = 0;

    long long input_time; // 来源时间

    vector<ID> Original_text;

    vector< INDEX > Text_node_storage_list;
    unordered_map<ID, vector<INDEX> > Id_to_node_idx;

    vector< vector<INDEX> > Text_node_space_storage_list;/* 文本推理节点存储，每原文8格收拢为一个vector，
    前8格按顺序存储原文字符*/

    vector<General_Cognition_Node> Text_local_node_list;
    vector<INDEX> Free_text_local_node_idx;
    unordered_map<ID, vector<INDEX> > Id_find_local_node_idx;

    unordered_set< vector<ID>, VectorUint32_tHash, VectorUint32_tEq > Text_combo_unordered;

    //
    unordered_map<ID, vector<Focus_Object> > Id_find_focus_list;

    vector<Attention_Object> Attention_object_List; // 注意力对象，关注、忽略的
    vector<INDEX> Free_attention_object_index;

    vector<INDEX> Overall_high_attention_idx;   //
    vector<INDEX> Free_overall_attention_idx;   //

    vector<Require_Object> Require_object_list; // 全体需求对象
    vector<int> Require_object_value; // 全体需求比重

    // 网格需求汇总侦测
    vector< vector<int> > Text_retrieve_require; // 8 倍汇总率，一个vector<int>记录当前8个格的需求
    vector< vector<int> > Text_model_require;    // 8 倍汇总率

    // 相关场景属性
    vector<Scene_Related> Relative_Scene_List;
};


// 文本界面显示
struct Gtk_Text_Interface_Display
{
    char use = 1;
    char have_init = 0;
    char response_aim_kind; // 解释1 回答2 求知3 追求4 对待5 赋予6
    
    char input_value_num = 0;
    char input_value_kind;

    int input_value_I[4];
    /*
    0、注意力/工作算力
    1、外部追求倾向、外部满足程度、外部追求需求、内部理解需求、内部识别程度(清楚度)、群体推演性(合理性)、注意力
    2、
    3、
    4、
    5、外部追求倾向、内部理解需求、注意力
    6、外部追求倾向、清楚度
    */

    char response_value_num = 0;
    char response_value_kind;
    
    int response_value[4];
    /*
    1、外部追求倾向、清楚度、注意力
    2、
    3、
    4、
    5、
    6、
    */

    /*任务特性*/
    /*外部性 内部性*/
    /*一次性 持续性*/
    /*求解性 赋予性*/
    /*单象性 双象性*/
    /*主动性 被动性*/
    /*根本性 运行性*/

    INDEX input_Text_Scene_Idx = 0;
    INDEX response_Text_Scene_Idx = 0;

    vector<char> Input_string;
    vector<char> Response_string;
};



/*模型的最高准则

    <1> 尽可能地认知当前世界，低消耗地、准确地、全面地
    <2> 在1的基础上，符合期望地执行界面输入的内容

*/



//
struct Feeling_of_Emotion
{
    int value; // 未处理度、不清楚度/好奇度  内部达成度、外部达成度/需求度 评估Appraisse
    INDEX self_source;
    int duration;
};


// 反馈 奖励
struct Feedback_Reward
{
    bool is_use = 1;
    int joy_value;               // 奖励
    float independent_attention; // 情绪注意力
    int duration;                // 持续时间
};

//感知 归因 反馈

// 线程核调度信息
struct Single_Thread
{
    char now_normal_work = 1;
    short need_free_time = 0;

    //vector<INDEX> future_invest_task; // 投入任务，无用
    //线程反馈任务提醒
};


/*
 *
 *核心存储区
 *
 */


// 线程管理
int Base_Thread_Num = 4;
int Calculate_Thread_Num = 0;
int Use_Thread_Num = Base_Thread_Num + Calculate_Thread_Num;
vector<Single_Thread> Thread_Handle_List;
float Thread_Limit_Free_Rate = 0.3; // 线程闲置度，防cpu过热

// 收发处理
vector<Model_Output_Action> Watting_Action_List; // 待发送行动
atomic<char> Send_Action_Number(0);

vector<char> Send_Text_List; // 待发送文本
atomic<bool> Text_Is_Send(0);

vector<char> Receive_Text_List; // 接受文本


// 对象需求
int Total_Task_Attention = 100 * Calculate_Thread_Num; 
int Free_Total_Task_Attention = Total_Task_Attention;
/* 线程处理所使用的注意力，恒定于线程数量，不能被增改 */

unordered_map< ID, vector<Focus_Object> > Id_Find_Focus_Object; // 全体关注对象

vector<Attention_Object> Attention_Object_List; // 注意力对象，关注、忽略的
vector<INDEX> Free_Attention_Object_Index;

atomic<long long> Model_Total_Derive_Attention;
/* 神经元内自生的注意力 */

vector<Require_Object> Require_Object_List; // 对象需求
vector<INDEX> Free_Require_Object_Idx;
atomic<long long> Model_Total_Require; // 需求的总量
/* 需求的总量，用于确定 sth/total 以获取所能占总值 ，以进入正式目标对象：*/

vector<Generate_Match> Generate_Match_List; // 生成匹配
vector<INDEX> Free_Generate_Match_Idx;

vector<Stat_Wait_Add_To_Neuro> Wait_Added_Record_List; // 待追加记录
vector<INDEX> Free_Wait_Added_Record_Idx;


// 目标相关
// 任务需求
atomic<int> un_perceive_value = 0; // 未认知/可认知
vector<Scene_Related> All_Perceive_Object;
vector<int> All_Perceive_Require;
vector<INDEX> Blank_Perceive_Object_List;

unordered_map< long long, INDEX> time_to_image_idx;

atomic<int> un_acquire_value = 0; // 未获取/可获取
vector<Require_Object> All_Acquire_Object;
vector<int> All_Acquire_Require;
vector<INDEX> Blank_Acquire_Object_List;

//正式目标对象：>128分之一，否则，只能存在于一般注意与需求对象

/*认知、追求 是一切欲望的来源*/

// 当下关注
int current_attention = 100;
int free_attention = 0;
vector<Attention_Object> Current_Attention_Object_List; // 更是总体关注
vector<INDEX> Free_Current_Attention_Object_Index; // 

unordered_map<ID, INDEX> node_summary; // 统合的注意力与全体数量


// 行动相关
vector<Model_Output_Action> action_choose_list; // 行动列表，在外部环境中实现
vector<int> action_choose_weights;

short Current_X = 0;
short Current_Y = 0;
bool Current_Interface_Show = 1;
bool Current_Interface_Text_Have = 0;
bool Current_Text_Show = 0;


// 奖励相关
vector<Feedback_Reward> provide_emotion; // 宜100~200
vector<INDEX> free_emotion_list; // 空情绪位置回收

int Current_Joy = 0;
int Approach_Joy = 0;
int Satisfy_Standard = 0000;


// 图像场景存储
vector<Image_Scene> Image_Scene_Storage;
vector<INDEX> Free_Image_Scene_Index;
vector<INDEX> New_Image_Scene_Index;
atomic<int> Image_Scene_Num = 0;
unordered_map<long long, INDEX> Time_To_Image_Search;
INDEX Newist_Image_Idx = 0;

// 文本场景存储
vector<Text_Scene> Text_Scene_Storage;
vector<INDEX> Free_Text_Scene_Index;
vector<INDEX> New_Text_Scene_Index;
atomic<int> Text_Scene_Num = 0;
unordered_map<long long, INDEX> Search_Text_Scene;

vector<Gtk_Text_Interface_Display> gtk3_text_display; // 界面显示

// 认知节点存储
vector<General_Cognition_Node> General_Cognition_Node_Storage;
vector< atomic<char> > General_Cognition_Node_Occupy;
atomic<int> Storage_General_Cognition_Node_Occupy(0);

atomic<long long> General_Cognition_Node_Num;
unordered_map< ID, vector<INDEX> > Search_General_Cognition_Node;

vector<INDEX> Free_General_Cognition_Node_Index;
atomic<int> Storage_Free_General_Cognition_Node_Index_Occupy(0);


// 通用场景存储
vector<General_Scene> General_Cognition_Scene_Storage;
vector< atomic<char> > General_Cognition_Scene_Occupy;
atomic<int> Storage_General_Cognition_Scene_Occupy(0);

vector<INDEX> Free_General_Cognition_Scene_Index;
atomic<int> Storage_Free_General_Cognition_Scene_Index_Occupy(0);

atomic<int> General_Cognition_Scene_Num = 0;

// 全局思考场景
General_Scene OVERALL_THINKING_SCENE;

// 时间场景查找
unordered_map<long long, INDEX> Search_Time_Scene;
vector<INDEX> Time_Scene_Storage;
atomic<INDEX> Oldest_Time_Scene = 0;

unordered_map< long long, INDEX > every_8_time_event; //图、文、推测、模拟、知识未知
long long CURRENT_8_gap_MODEL_TIME;
long long gap_8_operate_value = 0x8 * 100;
atomic<int> is_new_CURRENT_8_gap_MODEL_TIME(0);

unordered_map< long long, INDEX > every_32_time_event;
long long CURRENT_32_gap_MODEL_TIME;
long long gap_32_operate_value = 0x20 * 100;
atomic<int> is_new_CURRENT_32_gap_MODEL_TIME(0);

// 预测关注反馈
deque< vector<INDEX> > Fixed_Event_Predict_List; // Attention_Object下标

vector<INDEX> Total_Event_Predict_List; // Attention_Object下标
vector<INDEX> Free_Event_Predict_Idx;

/*
 *
 * fin
 *
 */


//对多线程使用方案 的使用函数
INDEX create_a_General_Cognition_Node()
{
    INDEX idx;

    int expected = 0;
    while( Storage_Free_General_Cognition_Node_Index_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
        expected = 0;

    expected = 0;
    while( Storage_General_Cognition_Node_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
        expected = 0;

    if (!Free_General_Cognition_Node_Index.empty())
    {
        idx = Free_General_Cognition_Node_Index.back();
        Free_General_Cognition_Node_Index.pop_back();

    } else {
        General_Cognition_Node new_thing;
        idx = General_Cognition_Node_Storage.size();
        General_Cognition_Node_Storage.push_back(new_thing);
    }

    General_Cognition_Node_Num++;

    expected = 1;
    while( Storage_Free_General_Cognition_Node_Index_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
        expected = 1;

    expected = 1;
    while( Storage_General_Cognition_Node_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
        expected = 1;

    return idx;
}

INDEX create_a_General_Cognition_Node(General_Cognition_Node new_node)
{
    INDEX idx;

    int expected = 0;
    while( Storage_Free_General_Cognition_Node_Index_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
        expected = 0;

    expected = 0;
    while( Storage_General_Cognition_Node_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
        expected = 0;

    if (!Free_General_Cognition_Node_Index.empty())
    {
        idx = Free_General_Cognition_Node_Index.back();
        Free_General_Cognition_Node_Index.pop_back();
        General_Cognition_Node_Storage[idx] = new_node;

    } else {
        idx = General_Cognition_Node_Storage.size();
        General_Cognition_Node_Storage.push_back(new_node);
    }

    General_Cognition_Node_Num++;

    expected = 1;
    while( Storage_Free_General_Cognition_Node_Index_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
        expected = 1;

    expected = 1;
    while( Storage_General_Cognition_Node_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
        expected = 1;

    return idx;
}

void release_a_General_Cognition_Node(INDEX idx)
{
    int expected = 0;
    while( Storage_Free_General_Cognition_Node_Index_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
        expected = 0;

    expected = 0;
    while( Storage_General_Cognition_Node_Occupy.compare_exchange_strong(expected, 1, memory_order_seq_cst) )
        expected = 0;
    
    General_Cognition_Node& release_node = General_Cognition_Node_Storage[idx];
    release_node.is_use = 0;
    Free_General_Cognition_Node_Index.push_back(idx);

    General_Cognition_Node_Num--;

    expected = 1;
    while( Storage_Free_General_Cognition_Node_Index_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
        expected = 1;

    expected = 1;
    while( Storage_General_Cognition_Node_Occupy.compare_exchange_strong(expected, 0, memory_order_seq_cst) )
        expected = 1;
}

General_Cognition_Node read_a_General_Cognition_Node(INDEX node_idx)
{
    General_Cognition_Node return_node;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    return_node = General_Cognition_Node_Storage[node_idx];

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 1;
    
    return return_node;
}

void write_a_General_Cognition_Node(INDEX node_idx, General_Cognition_Node write_context)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Cognition_Node& be_write_node = General_Cognition_Node_Storage[node_idx];
    write_context.Variable_list = be_write_node.Variable_list; // 可变区的更改容易造成写入冲突，要用下个函数写
    be_write_node = write_context;

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
}

//
void push_back_a_variable_object_to_General_Cognition_Node(INDEX node_idx, Variable_Attribute variable_object)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Cognition_Node_Storage[node_idx].Variable_list.push_back(variable_object);

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}


//节点属性：图像属性
void create_a_Node_Image_Attribute(INDEX node_idx, Node_ImageAttribute attribute)
{
    Variable_Attribute fo = {.node_image_attribute = attribute};

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    curr_node.Variable_list.push_back(fo);

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void release_a_Node_Image_Attribute(INDEX node_idx)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //删除节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_list = the_node.Variable_list;
    int object_size = link_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_list[q].node_image_attribute.kind_is_self_attribute == 1)
        {
            if (link_list[q].node_image_attribute.kind_is_Node_Image_Attribute == 1)
            {
                link_list[q].node_image_attribute.curr_is_use = 0;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

Node_ImageAttribute read_a_Node_ImageAttribute(INDEX node_idx)
{
    //读取节点属性

    Node_ImageAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_image_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_image_attribute.kind_is_Node_Image_Attribute == 1)
            {
                attribute = link_object_list[q].node_image_attribute;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    return attribute;
}

void write_a_Node_Image_Attribute(INDEX node_idx, Node_ImageAttribute write_attribute)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //填写节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_image_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_image_attribute.kind_is_Node_Image_Attribute == 1)
            {
                link_object_list[q].node_image_attribute = write_attribute;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}


//字符属性
void create_a_Node_Text_Attribute(INDEX node_idx, Node_TextAttribute attribute)
{
    Variable_Attribute fo = {.node_text_attribute = attribute};

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    curr_node.Variable_list.push_back(fo);

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void release_a_Node_Text_Attribute(INDEX node_idx)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //删除节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                link_object_list[q].node_text_attribute.curr_is_use = 0;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

Node_TextAttribute read_a_Node_Text_Attribute(INDEX node_idx)
{
    Node_TextAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& object_list = the_node.Variable_list;
    int object_size = object_list.size();
    
    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                attribute = object_list[q].node_text_attribute;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    return attribute;
}

void write_a_Node_Text_Attribute(INDEX node_idx, Node_TextAttribute write_attritube)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //填写节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                link_object_list[q].node_text_attribute = write_attritube;
                break;
            }
        }
    }
    
    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}


//时间属性
void create_a_Node_Time_Attribute(INDEX node_idx, Node_TimeAttribute attribute)
{
    Variable_Attribute fo = {.node_time_attribute = attribute};

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    curr_node.Variable_list.push_back(fo);

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void release_a_Node_Time_Attribute(INDEX node_idx)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //删除节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_time_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_time_attribute.kind_is_Node_Time_Attribute == 3)
            {
                link_object_list[q].node_time_attribute.curr_is_use = 0;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

}

Node_TimeAttribute read_a_Node_Time_Attribute(INDEX node_idx)
{
    Node_TimeAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    General_Cognition_Node &the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute> &object_list = the_node.Variable_list;
    int object_size = object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_time_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_time_attribute.kind_is_Node_Time_Attribute == 3)
            {
                attribute = object_list[q].node_time_attribute;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    return attribute;
}

void write_a_Node_Time_Attribute(INDEX node_idx, Node_TextAttribute write_attritube)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //填写节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_text_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_text_attribute.kind_is_Node_Text_Attribute == 2)
            {
                link_object_list[q].node_text_attribute = write_attritube;
                break;
            }
        }
    }
    
    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}


//数量属性
void create_a_Node_Number_Attribute(INDEX node_idx, Node_NumberAttribute attribute)
{
    Variable_Attribute fo = {.node_number_attribute = attribute};

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    curr_node.Variable_list.push_back(fo);

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void release_a_Node_Number_Attribute(INDEX node_idx)
{
    Node_NumberAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    //删除节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 3)
            {
                link_object_list[q].node_number_attribute.curr_is_use = 0;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

}

Node_NumberAttribute read_a_Node_Number_Attribute(INDEX node_idx)
{
    Node_NumberAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute> & object_list = the_node.Variable_list;
    int object_size = object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 3)
            {
                attribute = object_list[q].node_number_attribute;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    return attribute;

}

void write_a_Node_Number_Attribute(INDEX node_idx, Node_NumberAttribute write_attritube)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //填写节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 5)
            {
                link_object_list[q].node_number_attribute = write_attritube;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}


//行动属性
void create_a_Node_Motion_Attribute(INDEX node_idx, Node_MotionAttribute attribute)
{
    Variable_Attribute fo = {.node_motion_attribute = attribute};

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //创建节点属性
    General_Cognition_Node& curr_node = General_Cognition_Node_Storage[node_idx];
    curr_node.Variable_list.push_back(fo);

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void release_a_Node_Motion_Attribute(INDEX node_idx)
{
    Node_NumberAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    //删除节点属性
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_number_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_number_attribute.kind_is_Node_Number_Attribute == 3)
            {
                link_object_list[q].node_number_attribute.curr_is_use = 0;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

}

Node_MotionAttribute read_a_Node_Motion_Attribute(INDEX node_idx)
{
    Node_MotionAttribute attribute;

    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    General_Cognition_Node& the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute> & object_list = the_node.Variable_list;
    int object_size = object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (object_list[q].node_motion_attribute.kind_is_self_attribute == 1)
        {
            if (object_list[q].node_motion_attribute.kind_is_Node_Motion_Attribute == 5)
            {
                attribute = object_list[q].node_motion_attribute;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    return attribute;

}

void write_a_Node_Motion_Attribute(INDEX node_idx, Node_MotionAttribute write_attritube)
{
    char expect = 0;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;
    
    //填写节点属性
    General_Cognition_Node the_node = General_Cognition_Node_Storage[node_idx];
    vector<Variable_Attribute>& link_object_list = the_node.Variable_list;
    int object_size = link_object_list.size();

    for (int q = 0; q < object_size; q++)
    {
        if (link_object_list[q].node_motion_attribute.kind_is_self_attribute == 1)
        {
            if (link_object_list[q].node_motion_attribute.kind_is_Node_Motion_Attribute == 5)
            {
                link_object_list[q].node_motion_attribute = write_attritube;
                break;
            }
        }
    }

    expect = 1;
    while( General_Cognition_Node_Occupy[node_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}


struct Node_Sequence_Info
{
    ;
};

Node_Sequence_Info read_a_node_sequence_info(INDEX node_idx)
{
    Node_Sequence_Info node_sequence_info;

    return node_sequence_info;
}

//
INDEX create_a_Scene_Inside_Image_Match(
    vector<Image_Match>& Image_match_List, vector<INDEX>& Free_image_match_index,
    Image_Match& added_image_match)
{
    INDEX idx;

    if(!Free_image_match_index.empty())
    {
        idx = Free_image_match_index.back();
        Free_image_match_index.pop_back();
        Image_match_List[idx] = added_image_match;
    } else {
        idx = Image_match_List.size();
        Image_match_List.push_back(added_image_match);
    }

    return idx;
}

void release_a_Scene_inside_Image_Match(
    vector<uint32_t>& Free_image_match_index,
    INDEX target_idx)
{
    Free_image_match_index.push_back(target_idx);
}


//场景内的本地focus_object
void get_a_local_focus_object(int example_number, vector<INDEX> &storage_list, vector<INDEX> &free_list)
{
    if (!free_list.empty())
    {
        storage_list[free_list.back()] = example_number;
        free_list.pop_back();
    
    } else {
        storage_list.push_back(example_number);
    }
}

void clear_a_general_object(INDEX idx, vector<INDEX> &free_list)
{
    free_list.push_back(idx);
}


// 生成检索

// 注意对象
INDEX get_a_Attention_Object()
{
    INDEX idx;
    if(Free_Attention_Object_Index.size() != 0)
    {
        idx = Free_Attention_Object_Index.back();
        Free_Attention_Object_Index.pop_back();
    } else {
        idx = Attention_Object_List.size();
        Attention_Object ao;
        Attention_Object_List.push_back(ao);
    }
    
    return idx;
}

void clear_a_Attention_Object(INDEX idx)
{
    Attention_Object_List[idx].curr_use = 0;
    Free_Attention_Object_Index.push_back(idx);
}

// 需求对象
INDEX get_a_Require_Object()
{
    INDEX idx;
    if(Free_Require_Object_Idx.size() != 0)
    {
        idx = Free_Require_Object_Idx.back();
        Free_Require_Object_Idx.pop_back();

    } else {
        idx = Require_Object_List.size();
        Require_ID rid;
        Require_Object ro = {.the_ID = rid};
        Require_Object_List.push_back(ro);
    }
    
    return idx;
}

void clear_a_Require_Object(INDEX idx)
{
    Free_Require_Object_Idx.push_back(idx);
}

// 节点匹配生成
INDEX get_a_Generate_Match()
{
    INDEX idx;
    if(Free_Generate_Match_Idx.size() != 0)
    {
        idx = Free_Generate_Match_Idx.back();
        Free_Generate_Match_Idx.pop_back();

    } else {
        idx = Generate_Match_List.size();
        Generate_Match rm;
        Generate_Match_List.push_back(rm);
    }
    
    return idx;
}

void clear_a_Generate_Match(INDEX idx)
{
    Free_Generate_Match_Idx.push_back(idx);
}


INDEX read_require_summary(ID target)
{
    vector<Focus_Object>& chose_list = Id_Find_Focus_Object[target];

    for(int a = 0; a < chose_list.size(); a++)
    {
        Focus_Object& fo = chose_list[a];

        if(fo.kind = 3)
            return fo.target_idx;
    }
    
    return 0;
}

void add_local_scene_a_require_object(INDEX scene_idx, Require_Object add_object)
{
    //合并需求或新建需求
}

void update_local_scene_a_require_value(vector< vector<int> >& require_list, INDEX require_idx)
{
    //更新空间中的需求值
}

void text_require_object_update(vector< vector<int> >& require_list, INDEX require_idx,
    int change_num)
{
    int outside_size = require_list.size();

    for(int a = 0; a < outside_size; a++)
    {
        require_list[a][require_idx] += change_num;
        require_idx /= 8;
    }
}


//场景操作

INDEX create_a_Map_Scene(Image_Scene new_map)
{
    INDEX idx;

    if (Free_Image_Scene_Index.size() > 0)
    {
        idx = Free_Image_Scene_Index.back();
        Free_Image_Scene_Index.pop_back();
        Image_Scene_Storage[idx] = new_map;
        
    } else {
        idx = Image_Scene_Storage.size();
        Image_Scene_Storage.push_back(new_map);
    }

    Image_Scene_Num++;

    return idx;
}

void delete_a_Map_Scene(INDEX idx)
{
    Image_Scene_Storage[idx].curr_use = 0;
    Free_Image_Scene_Index.push_back(idx);
    Image_Scene_Num--;
    // clear;
    // reserve();
}


INDEX create_a_Text_Scene(Text_Scene new_text)
{
    INDEX idx;

    if (!Free_Text_Scene_Index.empty())
    {
        idx = Free_Text_Scene_Index.back();
        Free_Text_Scene_Index.pop_back();
        Text_Scene_Storage[idx] = new_text;

    } else {
        new_text.input_time = CURRENT_MODEL_TIME;
        idx = Text_Scene_Storage.size();
        Text_Scene_Storage.push_back(new_text);
    }

    Text_Scene_Num++;

    return idx;
}

void delete_a_Text_Scene(INDEX idx)
{
    Text_Scene& text = Text_Scene_Storage[idx];
    text.is_use = 0;
    Free_Text_Scene_Index.push_back(idx);
    Text_Scene_Num--;
}


INDEX create_a_gtk3_text_display(Gtk_Text_Interface_Display text_display)
{
    int i = 0;
    int size = gtk3_text_display.size();

    while (i < size)
    {
        if (gtk3_text_display[i].use == 0)
        {
            gtk3_text_display[i] = text_display;
            break;
        }

        i++;
    }

    if (i == size)
    {
        gtk3_text_display.push_back(text_display);
    }

    return i;
}

void delete_a_gtk3_text_display(INDEX idx)
{
    gtk3_text_display[idx].use = 0;
}


INDEX create_a_General_Scene()
{
    INDEX idx;
    General_Scene new_thing;

    int expect = 0;
    while( Storage_General_Cognition_Scene_Occupy.compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    expect = 0;
    while( Storage_Free_General_Cognition_Scene_Index_Occupy.compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    if (Free_General_Cognition_Scene_Index.size() > 0)
    {
        idx = Free_General_Cognition_Scene_Index.back();
        Free_General_Cognition_Scene_Index.pop_back();
    } else {
        idx = General_Cognition_Scene_Storage.size();
        General_Cognition_Scene_Storage.push_back(new_thing);
    }

    expect = 1;
    while( Storage_General_Cognition_Scene_Occupy.compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    expect = 1;
    while( Storage_Free_General_Cognition_Scene_Index_Occupy.compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    General_Cognition_Scene_Num++;

    return idx;
}

INDEX create_a_General_Scene(General_Scene new_thing)
{
    INDEX idx;

    int expect = 0;
    while( Storage_General_Cognition_Scene_Occupy.compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    expect = 0;
    while( Storage_Free_General_Cognition_Scene_Index_Occupy.compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    if (Free_General_Cognition_Scene_Index.size() > 0)
    {
        idx = Free_General_Cognition_Scene_Index.back();
        Free_General_Cognition_Scene_Index.pop_back();
        General_Cognition_Scene_Storage[idx] = new_thing;
    } else {
        idx = General_Cognition_Scene_Storage.size();
        General_Cognition_Scene_Storage.push_back(new_thing);
    }

    expect = 1;
    while( Storage_General_Cognition_Scene_Occupy.compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    expect = 1;
    while( Storage_Free_General_Cognition_Scene_Index_Occupy.compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    General_Cognition_Scene_Num++;

    return idx;
}

void delete_a_General_Scene(INDEX idx)
{
    int expect = 0;
    while( Storage_General_Cognition_Scene_Occupy.compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    char expect_ = 0;
    while( General_Cognition_Scene_Occupy[idx].compare_exchange_strong(expect_, 1, memory_order_seq_cst) )
        expect = 0;
    
    
    General_Scene& the_scene = General_Cognition_Scene_Storage[idx];
    the_scene.All_have_node_idx_list.reserve(0);
    Free_General_Cognition_Scene_Index.push_back(idx);


    expect = 1;
    while( Storage_Free_General_Cognition_Scene_Index_Occupy.compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;

    expect_ = 1;
    while( General_Cognition_Scene_Occupy[idx].compare_exchange_strong(expect_, 0, memory_order_seq_cst) )
        expect_ = 1;

    General_Cognition_Scene_Num--;
}

INDEX find_a_()
{
    ;
}

void push_back_a_node_to_General_Scene(INDEX scene_idx, INDEX node_idx)
{
    Object_LinkAttribute link;
    Variable_Attribute va = {.object_link_attribute = link}; // number_node的
    
    char expect = 0;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Scene& scene = General_Cognition_Scene_Storage[scene_idx];
    scene.All_have_node_idx_list.push_back(node_idx);
    General_Cognition_Node& node = General_Cognition_Node_Storage[node_idx];
    ID node_id = node.self_id;
    scene.Id_find_node_idx[node_id].push_back(node_idx);
    

    expect = 1;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

void push_back_a_related_scene_to_General_Scene(INDEX scene_idx, Scene_Related push_related)
{
    char expect = 0;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 1, memory_order_seq_cst) )
        expect = 0;

    General_Scene& scene = General_Cognition_Scene_Storage[scene_idx];
    scene.Scene_related_list.push_back(push_related);

    expect = 1;
    while( General_Cognition_Scene_Occupy[scene_idx].compare_exchange_strong(expect, 0, memory_order_seq_cst) )
        expect = 1;
}

Scene_Related read_a_scene_related_motion_detect(INDEX scene_idx)
{
    ;
}

/*涓栫晫娣卞眰鏀垮簻缃伓婊斿ぉ銆佹伓璐弧鐩�*/

// 保存上一次的时间戳和steady_clock的参考点
static auto last_staedy_time = std::chrono::steady_clock::now();
static int32_t last_system_seconds = 0;

// 秒级时间获取
int get_current_second()
{
    // 获取当前时间点
    auto system_now = std::chrono::system_clock::now();

    int current_system_seconds = std::chrono::duration_cast<std::chrono::seconds>(system_now.time_since_epoch()).count();

    if (current_system_seconds < last_system_seconds)
    {
        std::cout << "警告：系统时间回拨";
    }
    else
    {
        // 时间状态更新
        last_system_seconds = current_system_seconds;
    }
    // 转换为格林威治时间
    return current_system_seconds;
} // 函数结束

// 秒数更新判断
bool check_time_updated()
{
    static auto last_time = std::chrono::system_clock::now(); // 保存上一次时间点

    // 获取当前时间并转换为秒级精度
    auto current_time = std::chrono::system_clock::now();
    auto current_sec = std::chrono::duration_cast<std::chrono::seconds>(current_time.time_since_epoch());
    auto last_sec = std::chrono::duration_cast<std::chrono::seconds>(last_time.time_since_epoch());

    // 比较是否进入新的一秒
    if (current_sec > last_sec)
    {
        last_time = current_time; // 更新记录的时间点
        return true;
    }
    return false;
} // 函数结束

// 模型时间更新
int stat_gap_time()
{
    auto steady_now = std::chrono::steady_clock::now();
    int steady_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(steady_now - last_staedy_time).count();
    last_staedy_time = steady_now;

    return steady_elapsed;
} // 函数结束

// 100毫秒时间的设置作为模型中的一基本单位时间
chrono::milliseconds hundred_ms(100);


inline long long departure_time_to_time(int front_time, int back_time)
{
    long long true_time = front_time;
    true_time = true_time << 32;
    true_time |= back_time;
    return true_time;
}

inline void time_to_departure_time(long long true_time, int& front_time, int& back_time)
{
    front_time = true_time >> 32;
    back_time = true_time;
}